import { useState } from "react";
import { Route, Switch } from "wouter";
import Sidebar from "./components/layout/Sidebar";
import Header from "./components/layout/Header";
import Dashboard from "./pages/Dashboard";
import WaterFootprint from "./pages/WaterFootprint";
import ComparisonTools from "./pages/ComparisonTools";
import RegionalAnalysis from "./pages/RegionalAnalysis";
import Reports from "./pages/Reports";
import DataSources from "./pages/DataSources";
import Settings from "./pages/Settings";
import NotFound from "./pages/not-found";

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 text-neutral-900">
      {/* Sidebar for desktop */}
      <Sidebar className="hidden md:flex md:flex-shrink-0" />
      
      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header 
          toggleMobileMenu={toggleMobileMenu} 
          mobileMenuOpen={mobileMenuOpen}
        />
        
        {/* Mobile Navigation Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-b border-neutral-200">
              <a href="/" className="block px-3 py-2 rounded-md text-base font-medium text-white bg-primary">
                <i className="ri-dashboard-line mr-2"></i>Dashboard
              </a>
              <a href="/water-footprint" className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100">
                <i className="ri-drop-line mr-2"></i>Water Footprint
              </a>
              <a href="/comparison-tools" className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100">
                <i className="ri-bar-chart-grouped-line mr-2"></i>Comparison Tools
              </a>
              <a href="/regional-analysis" className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100">
                <i className="ri-map-2-line mr-2"></i>Regional Analysis
              </a>
              <a href="/reports" className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100">
                <i className="ri-file-chart-line mr-2"></i>Reports
              </a>
              <a href="/data-sources" className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100">
                <i className="ri-database-2-line mr-2"></i>Data Sources
              </a>
              <a href="/settings" className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100">
                <i className="ri-settings-line mr-2"></i>Settings
              </a>
            </div>
          </div>
        )}
        
        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-neutral-50 p-4 sm:p-6 custom-scrollbar">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/water-footprint" component={WaterFootprint} />
            <Route path="/comparison-tools" component={ComparisonTools} />
            <Route path="/regional-analysis" component={RegionalAnalysis} />
            <Route path="/reports" component={Reports} />
            <Route path="/data-sources" component={DataSources} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
    </div>
  );
}

export default App;
