import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

export default function Recommendations() {
  const { data: recommendations } = useQuery<any[]>({
    queryKey: ['/api/recommendations'],
  });

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 to-blue-50 dark:from-emerald-950 dark:to-blue-950" />
      <CardHeader className="relative">
        <CardTitle className="flex items-center gap-2">
          <i className="ri-lightbulb-flash-line text-amber-500"></i>
          Water Efficiency Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent className="relative space-y-4">
        {recommendations?.map((rec, index) => (
          <div key={rec.id} className="bg-white/50 dark:bg-black/20 p-4 rounded-lg border border-neutral-200 dark:border-neutral-800">
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 flex items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900">
                <i className="ri-drop-line text-emerald-600 dark:text-emerald-400"></i>
              </div>
              <div>
                <h3 className="font-medium text-neutral-900 dark:text-neutral-100">{rec.title}</h3>
                <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-400">{rec.description}</p>
                <div className="mt-2 flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400">
                  <i className="ri-arrow-right-line"></i>
                  <span>Potential saving: {rec.potentialSaving}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}