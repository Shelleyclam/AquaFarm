
import { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { Region } from '@shared/schema';

const RegionalMap = () => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  
  const { data: regions, isLoading, error } = useQuery<Region[]>({
    queryKey: ['/api/regions'],
  });

  useEffect(() => {
    if (!mapContainerRef.current) return;

    const initializeMap = async () => {
      const L = await import('leaflet');
      import('leaflet/dist/leaflet.css');
      
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
      }
      
      const map = L.map(mapContainerRef.current, {
        zoomControl: true,
        scrollWheelZoom: true
      }).setView([23.5937, 78.9629], 5);
      
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);

      // Indian regions with coordinates
      const indianRegions = [
        { name: "Indo-Gangetic Plains", lat: 27.5, lng: 85.0, rainfall: 800 },
        { name: "Deccan Plateau", lat: 18.5, lng: 78.0, rainfall: 600 },
        { name: "Western Coastal Plains", lat: 15.0, lng: 74.0, rainfall: 2500 },
        { name: "Eastern Coastal Plains", lat: 17.0, lng: 82.0, rainfall: 1200 },
        { name: "Himalayan Region", lat: 32.0, lng: 77.0, rainfall: 1600 },
        { name: "Central Highlands", lat: 23.0, lng: 77.0, rainfall: 500 },
        { name: "Thar Desert", lat: 27.0, lng: 71.0, rainfall: 150 },
        { name: "North-Eastern Region", lat: 26.0, lng: 91.0, rainfall: 2000 }
      ];
      
      // Create a color scale for Indian rainfall patterns
      const getColor = (rainfall: number) => {
        if (rainfall > 3000) return '#0284C7';
        if (rainfall > 2000) return '#0EA5E9';
        if (rainfall > 1000) return '#38BDF8';
        if (rainfall > 500) return '#7DD3FC';
        return '#EF4444';
      };
      
      // Add markers for each region
      indianRegions.forEach(region => {
        const color = getColor(region.rainfall);
        
        const markerOptions = {
          radius: 12,
          fillColor: color,
          color: '#fff',
          weight: 1,
          opacity: 1,
          fillOpacity: 0.8
        };
        
        L.circleMarker([region.lat, region.lng], markerOptions)
          .addTo(map)
          .bindPopup(`
            <b>${region.name}</b><br>
            Rainfall: ${region.rainfall} mm/year<br>
            ${region.rainfall > 2000 ? 'High Rainfall Zone' : 
              region.rainfall > 1000 ? 'Moderate Rainfall Zone' : 
              region.rainfall > 500 ? 'Low Rainfall Zone' : 'Arid Zone'}
          `);
      });
      
      mapInstanceRef.current = map;
    };
    
    initializeMap();
    
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
      }
    };
  }, []);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Regional Water Distribution Map</CardTitle>
          <CardDescription>Loading map data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[350px] bg-neutral-100 animate-pulse rounded"></div>
        </CardContent>
      </Card>
    );
  }
  
  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Regional Water Distribution Map</CardTitle>
          <CardDescription>Error loading map data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[350px] flex items-center justify-center bg-neutral-100 rounded">
            <div className="text-error">Failed to load map data.</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Regional Water Distribution Map</CardTitle>
        <CardDescription>Geographic distribution of rainfall across Indian regions</CardDescription>
      </CardHeader>
      <CardContent>
        <div ref={mapContainerRef} className="h-[350px] rounded"></div>
        <div className="mt-4 flex justify-between items-center text-sm">
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 rounded-full bg-[#EF4444]"></span>
            <span className="ml-1 text-neutral-500">Arid (&lt;500mm)</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 rounded-full bg-[#7DD3FC]"></span>
            <span className="ml-1 text-neutral-500">Semi-arid (500-1000mm)</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 rounded-full bg-[#38BDF8]"></span>
            <span className="ml-1 text-neutral-500">Moderate (1000-2000mm)</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 rounded-full bg-[#0284C7]"></span>
            <span className="ml-1 text-neutral-500">High (&gt;2000mm)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RegionalMap;
