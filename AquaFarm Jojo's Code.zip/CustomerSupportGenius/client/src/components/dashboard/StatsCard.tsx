import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon?: string;
  trend?: {
    value: number;
    label: string;
  };
}

export default function StatsCard({ title, value, unit, icon, trend }: StatsCardProps) {
  return (
    <Card className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900" />
      <CardContent className="relative p-6 flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-neutral-600 dark:text-neutral-400">{title}</p>
          <div className="flex items-baseline mt-2">
            <p className="text-2xl font-bold">{value}</p>
            {unit && <p className="ml-1 text-sm text-neutral-600 dark:text-neutral-400">{unit}</p>}
          </div>
          {trend && (
            <div className="mt-2 flex items-center">
              <i className={`ri-arrow-${trend.value >= 0 ? 'up' : 'down'}-line text-${trend.value >= 0 ? 'green' : 'red'}-600 mr-1`}></i>
              <span className={`text-sm text-${trend.value >= 0 ? 'green' : 'red'}-600`}>
                {Math.abs(trend.value)}% {trend.label}
              </span>
            </div>
          )}
        </div>
        {icon && (
          <div className="h-12 w-12 flex items-center justify-center rounded-full bg-blue-600/10">
            <i className={`${icon} text-2xl text-blue-600`}></i>
          </div>
        )}
      </CardContent>
    </Card>
  );
}