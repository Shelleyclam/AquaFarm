import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Crop, Region, IrrigationMethod, WaterFootprint, Recommendation } from '@shared/schema';

const formSchema = z.object({
  cropId: z.string(),
  regionId: z.string(),
  irrigationMethodId: z.string(),
  area: z.string().min(1, 'Area is required').transform(v => parseFloat(v)),
  growingSeason: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

interface CalculationResult {
  waterFootprint: WaterFootprint;
  recommendations: Recommendation[];
  crop: Crop;
  region: Region;
  irrigationMethod: IrrigationMethod;
}

const WaterCalculator = () => {
  const [calculationResult, setCalculationResult] = useState<CalculationResult | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: crops, isLoading: cropsLoading } = useQuery<Crop[]>({
    queryKey: ['/api/crops'],
  });

  const { data: regions, isLoading: regionsLoading } = useQuery<Region[]>({
    queryKey: ['/api/regions'],
  });

  const { data: irrigationMethods, isLoading: methodsLoading } = useQuery<IrrigationMethod[]>({
    queryKey: ['/api/irrigation-methods'],
  });

  const calculateMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest('POST', '/api/calculate-water-footprint', data);
      return await response.json() as CalculationResult;
    },
    onSuccess: (data) => {
      setCalculationResult(data);
      toast({
        title: "Calculation Complete",
        description: "Water footprint has been calculated successfully",
      });
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      toast({
        title: "Calculation Failed",
        description: error.message || "Failed to calculate water footprint",
        variant: "destructive",
      });
    }
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cropId: "1", // Default to first crop
      regionId: "1", // Default to first region
      irrigationMethodId: "1", // Default to first method
      area: "10",
      growingSeason: "Spring-Summer",
    },
  });

  const onSubmit = (data: FormValues) => {
    calculateMutation.mutate(data);
  };

  const isLoading = cropsLoading || regionsLoading || methodsLoading;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Water Footprint Calculator</CardTitle>
          <CardDescription>Loading calculator data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-10 bg-neutral-200 rounded"></div>
            <div className="h-10 bg-neutral-200 rounded"></div>
            <div className="h-10 bg-neutral-200 rounded"></div>
            <div className="h-10 bg-neutral-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Water Footprint Calculator</CardTitle>
        <CardDescription>Estimate water usage for different scenarios</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="cropId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Crop Type</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    disabled={calculateMutation.isPending}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select crop type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {crops?.map(crop => (
                        <SelectItem key={crop.id} value={crop.id.toString()}>
                          {crop.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="regionId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Region</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    disabled={calculateMutation.isPending}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select region" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {regions?.map(region => (
                        <SelectItem key={region.id} value={region.id.toString()}>
                          {region.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="irrigationMethodId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Irrigation Method</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    disabled={calculateMutation.isPending}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select irrigation method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {irrigationMethods?.map(method => (
                        <SelectItem key={method.id} value={method.id.toString()}>
                          {method.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="area"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Area (ha)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number"
                      min="1"
                      max="1000"
                      {...field}
                      disabled={calculateMutation.isPending}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="growingSeason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Growing Season</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    disabled={calculateMutation.isPending}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select growing season" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Spring-Summer">Spring-Summer</SelectItem>
                      <SelectItem value="Summer-Fall">Summer-Fall</SelectItem>
                      <SelectItem value="Fall-Winter">Fall-Winter</SelectItem>
                      <SelectItem value="Winter-Spring">Winter-Spring</SelectItem>
                      <SelectItem value="Year-Round">Year-Round</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full"
              disabled={calculateMutation.isPending}
            >
              {calculateMutation.isPending ? (
                <>Calculating...</>
              ) : (
                <>
                  <i className="ri-calculator-line mr-2"></i> Calculate Water Footprint
                </>
              )}
            </Button>
          </form>
        </Form>

        {/* Results Section */}
        {calculationResult && (
          <div className="mt-6 p-4 bg-neutral-50 rounded-md border border-neutral-200">
            <h4 className="text-sm font-medium text-neutral-900 mb-2">Estimated Water Footprint:</h4>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-neutral-600">Total Water Usage:</span>
              <span className="text-sm font-semibold text-neutral-900">
                {Math.round(calculationResult.waterFootprint.waterUsage).toLocaleString()} m³
              </span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-neutral-600">Water Efficiency Rating:</span>
              <span className={`text-sm font-semibold ${
                calculationResult.waterFootprint.waterEfficiencyScore > 75 
                  ? 'text-success' 
                  : calculationResult.waterFootprint.waterEfficiencyScore > 50 
                    ? 'text-accent' 
                    : 'text-error'
              }`}>
                {calculationResult.waterFootprint.waterEfficiencyScore > 75 
                  ? 'Good' 
                  : calculationResult.waterFootprint.waterEfficiencyScore > 50 
                    ? 'Moderate' 
                    : 'Poor'
                }
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-neutral-600">Potential Savings:</span>
              <span className="text-sm font-semibold text-accent">
                Up to {Math.round(calculationResult.waterFootprint.potentialSavings).toLocaleString()} m³
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default WaterCalculator;