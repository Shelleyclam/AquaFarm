import { useState } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from '@tanstack/react-query';

// Month names for display
const MONTHS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

interface ChartData {
  name: string;
  currentYear: number;
  previousYear: number;
}

interface ApiResponse {
  currentYear: {
    year: number;
    data: {
      id: number;
      userId: number;
      month: number;
      year: number;
      waterUsage: number;
    }[];
  };
  previousYear: {
    year: number;
    data: {
      id: number;
      userId: number;
      month: number;
      year: number;
      waterUsage: number;
    }[];
  };
}

const WaterUsageChart = () => {
  const [timeframe, setTimeframe] = useState<'monthly' | 'quarterly' | 'yearly'>('monthly');
  
  const { data, isLoading, error } = useQuery<ApiResponse>({
    queryKey: ['/api/monthly-water-usage'],
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Water Usage by Month</CardTitle>
          <CardDescription>Loading chart data...</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px] flex items-center justify-center">
          <div className="animate-pulse flex space-x-4">
            <div className="w-full h-full bg-neutral-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Water Usage by Month</CardTitle>
          <CardDescription>Error loading chart data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-error">Failed to load water usage data.</div>
        </CardContent>
      </Card>
    );
  }
  
  const prepareChartData = (): ChartData[] => {
    if (!data) return [];
    
    // For monthly data
    if (timeframe === 'monthly') {
      return MONTHS.map((month, index) => {
        const currentYearData = data.currentYear.data.find(d => d.month === index + 1);
        const previousYearData = data.previousYear.data.find(d => d.month === index + 1);
        
        return {
          name: month,
          currentYear: currentYearData?.waterUsage || 0,
          previousYear: previousYearData?.waterUsage || 0
        };
      });
    }
    
    // For quarterly data
    if (timeframe === 'quarterly') {
      const quarters = ['Q1', 'Q2', 'Q3', 'Q4'];
      
      return quarters.map((quarter, index) => {
        // Calculate months in this quarter
        const startMonth = index * 3;
        const endMonth = startMonth + 2;
        
        // Sum the water usage for the months in this quarter
        let currentYearSum = 0;
        let previousYearSum = 0;
        
        for (let i = startMonth; i <= endMonth; i++) {
          const currentYearData = data.currentYear.data.find(d => d.month === i + 1);
          const previousYearData = data.previousYear.data.find(d => d.month === i + 1);
          
          currentYearSum += currentYearData?.waterUsage || 0;
          previousYearSum += previousYearData?.waterUsage || 0;
        }
        
        return {
          name: quarter,
          currentYear: currentYearSum,
          previousYear: previousYearSum
        };
      });
    }
    
    // For yearly data
    if (timeframe === 'yearly') {
      const currentYearSum = data.currentYear.data.reduce((sum, month) => sum + month.waterUsage, 0);
      const previousYearSum = data.previousYear.data.reduce((sum, month) => sum + month.waterUsage, 0);
      
      return [
        {
          name: data.previousYear.year.toString(),
          currentYear: 0,
          previousYear: previousYearSum
        },
        {
          name: data.currentYear.year.toString(),
          currentYear: currentYearSum,
          previousYear: 0
        }
      ];
    }
    
    return [];
  };
  
  const chartData = prepareChartData();
  
  // Calculate totals
  const currentYearTotal = data?.currentYear.data.reduce((sum, month) => sum + month.waterUsage, 0) || 0;
  const previousYearTotal = data?.previousYear.data.reduce((sum, month) => sum + month.waterUsage, 0) || 0;
  const difference = ((currentYearTotal - previousYearTotal) / previousYearTotal) * 100;
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle>Water Usage by Month</CardTitle>
          <CardDescription>Comparative analysis of water consumption</CardDescription>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant={timeframe === 'monthly' ? 'secondary' : 'outline'} 
            onClick={() => setTimeframe('monthly')}
            size="sm"
          >
            Monthly
          </Button>
          <Button 
            variant={timeframe === 'quarterly' ? 'secondary' : 'outline'} 
            onClick={() => setTimeframe('quarterly')}
            size="sm"
          >
            Quarterly
          </Button>
          <Button 
            variant={timeframe === 'yearly' ? 'secondary' : 'outline'} 
            onClick={() => setTimeframe('yearly')}
            size="sm"
          >
            Yearly
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{
                top: 10,
                right: 30,
                left: 0,
                bottom: 0,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="currentYear"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                name={`Current Year (${data?.currentYear.year})`}
              />
              <Line
                type="monotone"
                dataKey="previousYear"
                stroke="hsl(var(--muted-foreground))"
                strokeWidth={2}
                name={`Previous Year (${data?.previousYear.year})`}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-sm font-medium text-neutral-500">Current Year</p>
            <p className="text-lg font-semibold text-primary">{currentYearTotal.toLocaleString()} m³</p>
          </div>
          <div>
            <p className="text-sm font-medium text-neutral-500">Previous Year</p>
            <p className="text-lg font-semibold text-neutral-700">{previousYearTotal.toLocaleString()} m³</p>
          </div>
          <div>
            <p className="text-sm font-medium text-neutral-500">Difference</p>
            <p className={`text-lg font-semibold ${difference < 0 ? 'text-success' : 'text-error'}`}>
              {difference.toFixed(1)}%
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WaterUsageChart;
