import { useState } from "react";

interface HeaderProps {
  toggleMobileMenu: () => void;
  mobileMenuOpen: boolean;
}

const Header = ({ toggleMobileMenu, mobileMenuOpen }: HeaderProps) => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    // You can implement actual dark mode toggling here
    // For now, it's just a visual toggle
  };

  return (
    <header className="bg-white border-b border-neutral-200">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button 
              type="button" 
              className="inline-flex items-center justify-center p-2 rounded-md text-neutral-400 hover:text-neutral-500 hover:bg-neutral-100 focus:outline-none"
              onClick={toggleMobileMenu}
              aria-expanded={mobileMenuOpen}
            >
              <i className="ri-menu-line text-xl"></i>
            </button>
          </div>
          
          {/* Mobile Logo */}
          <div className="flex items-center md:hidden">
            <div className="flex-shrink-0 text-primary text-xl">
              <i className="ri-water-flash-line"></i>
            </div>
            <h1 className="ml-2 text-lg font-semibold text-neutral-900">AquaFarm</h1>
          </div>
          
          {/* Search Bar */}
          <div className="hidden md:flex items-center flex-1 ml-4 mr-4">
            <div className="relative w-full max-w-xl">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <i className="ri-search-line text-neutral-400"></i>
              </div>
              <input 
                type="text" 
                className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md leading-5 bg-neutral-50 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary sm:text-sm" 
                placeholder="Search crops, regions, or metrics..."
              />
            </div>
          </div>
          
          {/* Right Header Items */}
          <div className="flex items-center">
            {/* Notifications */}
            <button className="p-2 text-neutral-500 rounded-full hover:text-neutral-600 hover:bg-neutral-100">
              <i className="ri-notification-3-line text-xl"></i>
            </button>
            
            {/* Help */}
            <button className="p-2 text-neutral-500 rounded-full hover:text-neutral-600 hover:bg-neutral-100">
              <i className="ri-question-line text-xl"></i>
            </button>
            
            {/* Light/Dark mode toggle */}
            <button 
              className="p-2 ml-1 text-neutral-500 rounded-full hover:text-neutral-600 hover:bg-neutral-100"
              onClick={toggleDarkMode}
            >
              <div className={`relative w-10 h-5 bg-neutral-200 rounded-full flex items-center cursor-pointer ${isDarkMode ? 'dark-mode' : ''}`}>
                <div className="toggle-circle absolute left-0 w-5 h-5 bg-white rounded-full shadow-md transform transition-transform"></div>
                <i className="ri-sun-line absolute left-0.5 text-xs text-yellow-500"></i>
                <i className="ri-moon-line absolute right-0.5 text-xs text-neutral-500"></i>
              </div>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
