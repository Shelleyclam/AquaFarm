import { Link, useLocation } from "wouter";

interface SidebarProps {
  className?: string;
}

const Sidebar = ({ className = "" }: SidebarProps) => {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <div className={`${className}`}>
      <div className="flex flex-col w-64 border-r border-neutral-200">
        {/* Logo and App Title */}
        <div className="flex items-center justify-center h-16 px-4 border-b border-neutral-200">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-primary text-2xl">
              <i className="ri-water-flash-line"></i>
            </div>
            <h1 className="ml-2 text-xl font-semibold text-neutral-900">AquaFarm</h1>
          </div>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 px-2 py-4 space-y-1 bg-white overflow-y-auto custom-scrollbar">
          <Link href="/">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-dashboard-line mr-3 text-lg"></i>
              Dashboard
            </a>
          </Link>
          <Link href="/water-footprint">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/water-footprint') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-drop-line mr-3 text-lg"></i>
              Water Footprint
            </a>
          </Link>
          <Link href="/comparison-tools">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/comparison-tools') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-bar-chart-grouped-line mr-3 text-lg"></i>
              Comparison Tools
            </a>
          </Link>
          <Link href="/regional-analysis">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/regional-analysis') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-map-2-line mr-3 text-lg"></i>
              Regional Analysis
            </a>
          </Link>
          <Link href="/reports">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/reports') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-file-chart-line mr-3 text-lg"></i>
              Reports
            </a>
          </Link>
          <Link href="/data-sources">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/data-sources') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-database-2-line mr-3 text-lg"></i>
              Data Sources
            </a>
          </Link>
          <Link href="/settings">
            <a className={`flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/settings') ? 'bg-primary text-white' : 'text-neutral-700 hover:bg-neutral-100'}`}>
              <i className="ri-settings-line mr-3 text-lg"></i>
              Settings
            </a>
          </Link>
        </nav>
        
        {/* User Profile */}
        <div className="flex items-center p-4 border-t border-neutral-200">
          <div className="w-8 h-8 rounded-full bg-primary-light flex items-center justify-center text-white">
            <span>JD</span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-neutral-800">Jane Doe</p>
            <p className="text-xs text-neutral-500">Farm Manager</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
