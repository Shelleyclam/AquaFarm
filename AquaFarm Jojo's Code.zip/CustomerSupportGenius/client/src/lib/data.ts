// Any utility functions for working with water footprint data

// Calculate water usage based on crop, region, and irrigation method
export const calculateWaterUsage = (
  cropWaterRequirement: number, 
  area: number, 
  irrigationEfficiency: number
): number => {
  // Formula: base water requirement * area * (1 - efficiency)
  // Higher efficiency means lower water usage
  return cropWaterRequirement * area * (1 - irrigationEfficiency);
};

// Calculate efficiency score (0-100)
export const calculateEfficiencyScore = (
  irrigationEfficiency: number
): number => {
  // Simple conversion to 0-100 scale
  return Math.round(irrigationEfficiency * 100);
};

// Calculate potential water savings
export const calculatePotentialSavings = (
  baseWaterUsage: number, 
  waterSavingsPercentage: number
): number => {
  return baseWaterUsage * waterSavingsPercentage;
};

// Format number with thousands separators
export const formatNumber = (num: number): string => {
  return num.toLocaleString();
};

// Get color for efficiency score
export const getEfficiencyColor = (score: number): string => {
  if (score >= 75) return 'text-success';
  if (score >= 50) return 'text-accent';
  return 'text-error';
};

// Get rating text based on score
export const getEfficiencyRating = (score: number): string => {
  if (score >= 75) return 'Good';
  if (score >= 50) return 'Moderate';
  return 'Poor';
};

// Convert liters to cubic meters
export const litersToM3 = (liters: number): number => {
  return liters / 1000;
};

// Convert cubic meters to liters
export const m3ToLiters = (m3: number): number => {
  return m3 * 1000;
};

// Get month name from number
export const getMonthName = (monthNum: number): string => {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return months[monthNum - 1];
};

// Get short month name from number
export const getShortMonthName = (monthNum: number): string => {
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  return months[monthNum - 1];
};
