import { useState } from "react";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, ComposedChart, Area, Scatter, RadarChart, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';

// Sample data for comparison tools (India specific)
const crops = [
  { id: 1, name: "Rice", waterRequirement: 1200, yield: 3.5, revenue: 35000, unit: "t/ha" },
  { id: 2, name: "Wheat", waterRequirement: 450, yield: 3.2, revenue: 25000, unit: "t/ha" },
  { id: 3, name: "Sugarcane", waterRequirement: 1500, yield: 80, revenue: 120000, unit: "t/ha" },
  { id: 4, name: "Cotton", waterRequirement: 700, yield: 1.8, revenue: 60000, unit: "t/ha" },
  { id: 5, name: "Pulses", waterRequirement: 350, yield: 0.8, revenue: 40000, unit: "t/ha" },
  { id: 6, name: "Groundnut", waterRequirement: 600, yield: 1.5, revenue: 45000, unit: "t/ha" },
  { id: 7, name: "Maize", waterRequirement: 500, yield: 2.5, revenue: 30000, unit: "t/ha" },
];

const irrigationMethods = [
  { id: 1, name: "Drip Irrigation", efficiency: 90, installCost: 70000, maintenance: 5000, lifespan: 10 },
  { id: 2, name: "Sprinkler System", efficiency: 75, installCost: 50000, maintenance: 4000, lifespan: 8 },
  { id: 3, name: "Surface Irrigation", efficiency: 50, installCost: 15000, maintenance: 2000, lifespan: 15 },
  { id: 4, name: "Check Basin Method", efficiency: 60, installCost: 20000, maintenance: 3000, lifespan: 12 },
  { id: 5, name: "Micro Sprinkler", efficiency: 85, installCost: 60000, maintenance: 4500, lifespan: 10 },
  { id: 6, name: "Pitcher Irrigation", efficiency: 80, installCost: 25000, maintenance: 2500, lifespan: 5 },
];

const historicalData = {
  "Rice": [
    { year: 2020, waterUsage: 1350, yield: 3.1, revenue: 30000 },
    { year: 2021, waterUsage: 1320, yield: 3.2, revenue: 31500 },
    { year: 2022, waterUsage: 1280, yield: 3.3, revenue: 32500 },
    { year: 2023, waterUsage: 1240, yield: 3.4, revenue: 34000 },
    { year: 2024, waterUsage: 1200, yield: 3.5, revenue: 35000 },
  ],
  "Wheat": [
    { year: 2020, waterUsage: 480, yield: 2.8, revenue: 21000 },
    { year: 2021, waterUsage: 470, yield: 2.9, revenue: 22000 },
    { year: 2022, waterUsage: 465, yield: 3.0, revenue: 23000 },
    { year: 2023, waterUsage: 460, yield: 3.1, revenue: 24000 },
    { year: 2024, waterUsage: 450, yield: 3.2, revenue: 25000 },
  ],
  "Sugarcane": [
    { year: 2020, waterUsage: 1600, yield: 75, revenue: 105000 },
    { year: 2021, waterUsage: 1580, yield: 76, revenue: 108000 },
    { year: 2022, waterUsage: 1550, yield: 77, revenue: 112000 },
    { year: 2023, waterUsage: 1520, yield: 78, revenue: 115000 },
    { year: 2024, waterUsage: 1500, yield: 80, revenue: 120000 },
  ],
  "Cotton": [
    { year: 2020, waterUsage: 750, yield: 1.4, revenue: 50000 },
    { year: 2021, waterUsage: 740, yield: 1.5, revenue: 52000 },
    { year: 2022, waterUsage: 730, yield: 1.6, revenue: 54000 },
    { year: 2023, waterUsage: 710, yield: 1.7, revenue: 57000 },
    { year: 2024, waterUsage: 700, yield: 1.8, revenue: 60000 },
  ],
  "Maize": [
    { year: 2020, waterUsage: 550, yield: 2.1, revenue: 25000 },
    { year: 2021, waterUsage: 540, yield: 2.2, revenue: 26000 },
    { year: 2022, waterUsage: 530, yield: 2.3, revenue: 27000 },
    { year: 2023, waterUsage: 510, yield: 2.4, revenue: 28500 },
    { year: 2024, waterUsage: 500, yield: 2.5, revenue: 30000 },
  ],
  "Pulses": [
    { year: 2020, waterUsage: 380, yield: 0.6, revenue: 32000 },
    { year: 2021, waterUsage: 370, yield: 0.65, revenue: 34000 },
    { year: 2022, waterUsage: 365, yield: 0.7, revenue: 36000 },
    { year: 2023, waterUsage: 360, yield: 0.75, revenue: 38000 },
    { year: 2024, waterUsage: 350, yield: 0.8, revenue: 40000 },
  ],
  "Groundnut": [
    { year: 2020, waterUsage: 640, yield: 1.2, revenue: 38000 },
    { year: 2021, waterUsage: 630, yield: 1.3, revenue: 40000 },
    { year: 2022, waterUsage: 620, yield: 1.35, revenue: 41500 },
    { year: 2023, waterUsage: 610, yield: 1.4, revenue: 43000 },
    { year: 2024, waterUsage: 600, yield: 1.5, revenue: 45000 },
  ],
};

// Radar chart data for irrigation methods comparison
const irrigationRadarData = [
  {
    method: "Efficiency",
    "Drip Irrigation": 90,
    "Center Pivot": 80,
    "Sprinkler System": 75,
    "Flood Irrigation": 50,
    "Subsurface Drip": 95,
  },
  {
    method: "Cost Effectiveness",
    "Drip Irrigation": 75,
    "Center Pivot": 85,
    "Sprinkler System": 80,
    "Flood Irrigation": 90,
    "Subsurface Drip": 65,
  },
  {
    method: "Water Conservation",
    "Drip Irrigation": 95,
    "Center Pivot": 75,
    "Sprinkler System": 70,
    "Flood Irrigation": 40,
    "Subsurface Drip": 98,
  },
  {
    method: "Ease of Maintenance",
    "Drip Irrigation": 60,
    "Center Pivot": 75,
    "Sprinkler System": 80,
    "Flood Irrigation": 90,
    "Subsurface Drip": 55,
  },
  {
    method: "Adaptability",
    "Drip Irrigation": 80,
    "Center Pivot": 70,
    "Sprinkler System": 75,
    "Flood Irrigation": 45,
    "Subsurface Drip": 85,
  },
];

const waterFootprintComparison = [
  { crop: "Rice", greenWater: 1600, blueWater: 800, greyWater: 400, total: 2800 },
  { crop: "Wheat", greenWater: 1100, blueWater: 150, greyWater: 200, total: 1450 },
  { crop: "Sugarcane", greenWater: 900, blueWater: 1200, greyWater: 450, total: 2550 },
  { crop: "Cotton", greenWater: 2800, blueWater: 1800, greyWater: 500, total: 5100 },
  { crop: "Maize", greenWater: 950, blueWater: 350, greyWater: 220, total: 1520 },
  { crop: "Pulses", greenWater: 1300, blueWater: 170, greyWater: 180, total: 1650 },
  { crop: "Groundnut", greenWater: 1400, blueWater: 250, greyWater: 230, total: 1880 },
];

const ComparisonTools = () => {
  const [selectedCrop1, setSelectedCrop1] = useState("Rice");
  const [selectedCrop2, setSelectedCrop2] = useState("Wheat");
  const [selectedIrrigation1, setSelectedIrrigation1] = useState("Drip Irrigation");
  const [selectedIrrigation2, setSelectedIrrigation2] = useState("Surface Irrigation");
  const [areaSize, setAreaSize] = useState("100");

  // Calculate comparison metrics
  const crop1 = crops.find(c => c.name === selectedCrop1);
  const crop2 = crops.find(c => c.name === selectedCrop2);
  const irrigation1 = irrigationMethods.find(i => i.name === selectedIrrigation1);
  const irrigation2 = irrigationMethods.find(i => i.name === selectedIrrigation2);

  const acres = parseInt(areaSize) || 100;

  const calculatedData = {
    crop1: {
      waterUsage: crop1 ? crop1.waterRequirement * acres / (irrigation1?.efficiency || 100) * 100 : 0,
      yield: crop1 ? crop1.yield * acres : 0,
      revenue: crop1 ? crop1.revenue * acres : 0,
      roi: crop1 && irrigation1 ? (crop1.revenue * acres - irrigation1.installCost - irrigation1.maintenance) /
        (crop1.waterRequirement * acres / irrigation1.efficiency * 100) : 0,
    },
    crop2: {
      waterUsage: crop2 ? crop2.waterRequirement * acres / (irrigation2?.efficiency || 100) * 100 : 0,
      yield: crop2 ? crop2.yield * acres : 0,
      revenue: crop2 ? crop2.revenue * acres : 0,
      roi: crop2 && irrigation2 ? (crop2.revenue * acres - irrigation2.installCost - irrigation2.maintenance) /
        (crop2.waterRequirement * acres / irrigation2.efficiency * 100) : 0,
    }
  };

  // Prepare comparison chart data
  const cropComparisonData = [
    {
      metric: "Water Usage (m³)",
      [selectedCrop1]: calculatedData.crop1.waterUsage,
      [selectedCrop2]: calculatedData.crop2.waterUsage,
    },
    {
      metric: "Yield",
      [selectedCrop1]: calculatedData.crop1.yield,
      [selectedCrop2]: calculatedData.crop2.yield,
    },
    {
      metric: "Revenue (₹)",
      [selectedCrop1]: calculatedData.crop1.revenue,
      [selectedCrop2]: calculatedData.crop2.revenue,
    },
    {
      metric: "Water Efficiency (₹/m³)",
      [selectedCrop1]: calculatedData.crop1.revenue / calculatedData.crop1.waterUsage,
      [selectedCrop2]: calculatedData.crop2.revenue / calculatedData.crop2.waterUsage,
    }
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-neutral-900">Comparison Tools</h2>

      <Tabs defaultValue="crop-comparison" className="w-full">
        <TabsList className="w-full justify-start mb-6">
          <TabsTrigger value="crop-comparison" className="flex items-center">
            <i className="ri-plant-line mr-2"></i> Crop Comparison
          </TabsTrigger>
          <TabsTrigger value="irrigation-comparison" className="flex items-center">
            <i className="ri-drop-line mr-2"></i> Irrigation Methods
          </TabsTrigger>
          <TabsTrigger value="water-footprint" className="flex items-center">
            <i className="ri-footprint-line mr-2"></i> Water Footprint
          </TabsTrigger>
          <TabsTrigger value="scenario-analysis" className="flex items-center">
            <i className="ri-line-chart-line mr-2"></i> Scenario Analysis
          </TabsTrigger>
        </TabsList>

        <TabsContent value="crop-comparison" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Compare Crops and Irrigation Methods</CardTitle>
              <CardDescription>
                Select two different combinations of crops and irrigation methods to compare their water usage,
                yield, and economic metrics
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4 p-4 border rounded-lg">
                  <h3 className="font-semibold text-lg">Option 1</h3>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="crop1">Crop</Label>
                      <Select value={selectedCrop1} onValueChange={setSelectedCrop1}>
                        <SelectTrigger id="crop1">
                          <SelectValue placeholder="Select crop" />
                        </SelectTrigger>
                        <SelectContent>
                          {crops.map(crop => (
                            <SelectItem key={crop.id} value={crop.name}>
                              {crop.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="irrigation1">Irrigation Method</Label>
                      <Select value={selectedIrrigation1} onValueChange={setSelectedIrrigation1}>
                        <SelectTrigger id="irrigation1">
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent>
                          {irrigationMethods.map(method => (
                            <SelectItem key={method.id} value={method.name}>
                              {method.name} ({method.efficiency}% efficiency)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="pt-4 border-t space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Water Usage:</span>
                        <span className="font-medium">{calculatedData.crop1.waterUsage.toLocaleString()} m³</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Yield:</span>
                        <span className="font-medium">
                          {calculatedData.crop1.yield.toLocaleString()} {crop1?.unit}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Revenue:</span>
                        <span className="font-medium">₹{calculatedData.crop1.revenue.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Water Efficiency:</span>
                        <span className="font-medium">
                          ₹{(calculatedData.crop1.revenue / calculatedData.crop1.waterUsage).toFixed(2)}/m³
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 p-4 border rounded-lg">
                  <h3 className="font-semibold text-lg">Option 2</h3>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="crop2">Crop</Label>
                      <Select value={selectedCrop2} onValueChange={setSelectedCrop2}>
                        <SelectTrigger id="crop2">
                          <SelectValue placeholder="Select crop" />
                        </SelectTrigger>
                        <SelectContent>
                          {crops.map(crop => (
                            <SelectItem key={crop.id} value={crop.name}>
                              {crop.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="irrigation2">Irrigation Method</Label>
                      <Select value={selectedIrrigation2} onValueChange={setSelectedIrrigation2}>
                        <SelectTrigger id="irrigation2">
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent>
                          {irrigationMethods.map(method => (
                            <SelectItem key={method.id} value={method.name}>
                              {method.name} ({method.efficiency}% efficiency)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="pt-4 border-t space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Water Usage:</span>
                        <span className="font-medium">{calculatedData.crop2.waterUsage.toLocaleString()} m³</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Yield:</span>
                        <span className="font-medium">
                          {calculatedData.crop2.yield.toLocaleString()} {crop2?.unit}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Revenue:</span>
                        <span className="font-medium">₹{calculatedData.crop2.revenue.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Water Efficiency:</span>
                        <span className="font-medium">
                          ₹{(calculatedData.crop2.revenue / calculatedData.crop2.waterUsage).toFixed(2)}/m³
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-4">
                  <div className="space-y-2 w-full max-w-xs">
                    <Label htmlFor="area-size">Farm Area (acres)</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="area-size"
                        type="number"
                        placeholder="Area size"
                        value={areaSize}
                        onChange={(e) => setAreaSize(e.target.value)}
                      />
                      <Button onClick={() => setAreaSize("100")}>Reset</Button>
                    </div>
                    <p className="text-xs text-neutral-500">
                      All calculations are based on this farm area.
                    </p>
                  </div>

                  <div>
                    <Button variant="outline" onClick={() => window.print()}>
                      <i className="ri-file-chart-line mr-2"></i>
                      Print Analysis
                    </Button>
                  </div>
                </div>

                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={cropComparisonData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="metric" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey={selectedCrop1} fill="#3b82f6" />
                      <Bar dataKey={selectedCrop2} fill="#10b981" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4 text-sm text-neutral-500">
              <p>Data sources: USDA crop water requirements, yield statistics, and market prices</p>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Historical Trends: {selectedCrop1}</CardTitle>
              <CardDescription>
                Water usage, yield, and revenue trends over the past 5 years
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart
                    data={historicalData[selectedCrop1 as keyof typeof historicalData]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Bar yAxisId="left" dataKey="waterUsage" fill="#3b82f6" name="Water Usage (mm)" />
                    <Line yAxisId="right" type="monotone" dataKey="yield" stroke="#10b981" name={`Yield (${crop1?.unit})`} />
                    <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#f59e0b" name="Revenue (₹/acre)" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="irrigation-comparison" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Irrigation Methods Comparison</CardTitle>
                <CardDescription>
                  Compare different irrigation methods across key performance metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart outerRadius={150} data={irrigationRadarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="method" />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} />
                      <Radar
                        name="Drip Irrigation"
                        dataKey="Drip Irrigation"
                        stroke="#8884d8"
                        fill="#8884d8"
                        fillOpacity={0.2}
                      />
                      <Radar
                        name="Center Pivot"
                        dataKey="Center Pivot"
                        stroke="#82ca9d"
                        fill="#82ca9d"
                        fillOpacity={0.2}
                      />
                      <Radar
                        name="Sprinkler System"
                        dataKey="Sprinkler System"
                        stroke="#ffc658"
                        fill="#ffc658"
                        fillOpacity={0.2}
                      />
                      <Radar
                        name="Flood Irrigation"
                        dataKey="Flood Irrigation"
                        stroke="#ff8042"
                        fill="#ff8042"
                        fillOpacity={0.2}
                      />
                      <Radar
                        name="Subsurface Drip"
                        dataKey="Subsurface Drip"
                        stroke="#0088fe"
                        fill="#0088fe"
                        fillOpacity={0.2}
                      />
                      <Legend />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost-Benefit Analysis</CardTitle>
                <CardDescription>
                  Installation, maintenance, and efficiency metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Irrigation Method</TableHead>
                        <TableHead>Efficiency</TableHead>
                        <TableHead>Install Cost (₹/acre)</TableHead>
                        <TableHead>Annual Maintenance (₹/acre)</TableHead>
                        <TableHead>Lifespan</TableHead>
                        <TableHead className="text-right">ROI Rating</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {irrigationMethods.map((method) => {
                        // Simple ROI score calculation
                        const roiScore = (method.efficiency / 100) * method.lifespan /
                          (method.installCost / 1000 + method.maintenance / 100);

                        return (
                          <TableRow key={method.id}>
                            <TableCell className="font-medium">{method.name}</TableCell>
                            <TableCell>{method.efficiency}%</TableCell>
                            <TableCell>₹{method.installCost}</TableCell>
                            <TableCell>₹{method.maintenance}</TableCell>
                            <TableCell>{method.lifespan} years</TableCell>
                            <TableCell className="text-right">
                              <Badge
                                className={
                                  roiScore >= 0.7 ? 'bg-green-100 text-green-800 hover:bg-green-100' :
                                    roiScore >= 0.4 ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' :
                                      'bg-red-100 text-red-800 hover:bg-red-100'
                                }
                              >
                                {roiScore >= 0.7 ? 'Excellent' :
                                  roiScore >= 0.4 ? 'Good' :
                                    'Fair'}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>

                <div className="pt-6 space-y-4">
                  <h3 className="font-semibold text-lg">Irrigation Method Selection Guide</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border rounded-md p-3">
                      <h4 className="font-semibold text-green-700 mb-1">Best for Water Conservation</h4>
                      <p className="text-sm">
                        <span className="font-medium">Subsurface Drip:</span> Highest efficiency at 95%, directly delivers water to plant roots with minimal evaporation
                      </p>
                    </div>
                    <div className="border rounded-md p-3">
                      <h4 className="font-semibold text-amber-700 mb-1">Best Cost Effectiveness</h4>
                      <p className="text-sm">
                        <span className="font-medium">Center Pivot:</span> Good balance of efficiency (80%), moderate cost, and long lifespan (15 years)
                      </p>
                    </div>
                    <div className="border rounded-md p-3">
                      <h4 className="font-semibold text-blue-700 mb-1">Best for Large Fields</h4>
                      <p className="text-sm">
                        <span className="font-medium">Center Pivot:</span> Efficient coverage of large circular areas with automated operation
                      </p>
                    </div>
                    <div className="border rounded-md p-3">
                      <h4 className="font-semibold text-indigo-700 mb-1">Best for Small Farms</h4>
                      <p className="text-sm">
                        <span className="font-medium">Drip Irrigation:</span> Precise water delivery, excellent for small irregular fields and specialty crops
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="water-footprint" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Water Footprint Analysis</CardTitle>
              <CardDescription>
                Compare the water footprint components of different crops
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-2">Understanding Water Footprint Components</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-3 rounded-md border border-blue-100">
                    <h4 className="font-medium text-green-700">Green Water</h4>
                    <p className="text-sm text-neutral-600">
                      Rainwater stored in soil moisture that evaporates during crop growth
                    </p>
                  </div>
                  <div className="bg-white p-3 rounded-md border border-blue-100">
                    <h4 className="font-medium text-blue-700">Blue Water</h4>
                    <p className="text-sm text-neutral-600">
                      Surface and groundwater used for irrigation that evaporates during growth
                    </p>
                  </div>
                  <div className="bg-white p-3 rounded-md border border-blue-100">
                    <h4 className="font-medium text-neutral-600">Grey Water</h4>
                    <p className="text-sm text-neutral-600">
                      Freshwater required to assimilate pollutants to meet water quality standards
                    </p>
                  </div>
                </div>
              </div>

              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={waterFootprintComparison}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="crop" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="greenWater" stackId="a" fill="#22c55e" name="Green Water (mm)" />
                    <Bar dataKey="blueWater" stackId="a" fill="#3b82f6" name="Blue Water (mm)" />
                    <Bar dataKey="greyWater" stackId="a" fill="#64748b" name="Grey Water (mm)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Crop</TableHead>
                      <TableHead>Green Water (mm)</TableHead>
                      <TableHead>Blue Water (mm)</TableHead>
                      <TableHead>Grey Water (mm)</TableHead>                      <TableHead>Total (mm)</TableHead>
                      <TableHead className="text-right">Sustainability Rating</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {waterFootprintComparison.map((item) => {
                      // Calculate sustainability score based on green water percentage and total
                      const greenWaterPercentage = (item.greenWater / item.total) * 100;
                      const totalScore = item.total <= 700 ? 1 : item.total >= 1200 ? 0 : (1200 - item.total) / 500;
                      const sustainabilityScore = (greenWaterPercentage / 100 * 0.7) + (totalScore * 0.3);

                      return (
                        <TableRow key={item.crop}>
                          <TableCell className="font-medium">{item.crop}</TableCell>
                          <TableCell>{item.greenWater}</TableCell>
                          <TableCell>{item.blueWater}</TableCell>
                          <TableCell>{item.greyWater}</TableCell>
                          <TableCell className="font-medium">{item.total}</TableCell>
                          <TableCell className="text-right">
                            <Badge
                              className={
                                sustainabilityScore >= 0.7 ? 'bg-green-100 text-green-800 hover:bg-green-100' :
                                  sustainabilityScore >= 0.4 ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' :
                                    'bg-red-100 text-red-800 hover:bg-red-100'
                              }
                            >
                              {sustainabilityScore >= 0.7 ? 'High' :
                                sustainabilityScore >= 0.4 ? 'Medium' :
                                  'Low'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4 text-sm text-neutral-500">
              <p>Data Source: Water Footprint Network and research studies on agricultural water usage</p>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="scenario-analysis" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Scenario Analysis Tool</CardTitle>
              <CardDescription>
                Analyze the impact of different scenarios on water usage and crop yields
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="scenario-crop">Crop Type</Label>
                  <Select defaultValue="Corn">
                    <SelectTrigger id="scenario-crop">
                      <SelectValue placeholder="Select crop" />
                    </SelectTrigger>
                    <SelectContent>
                      {crops.map(crop => (
                        <SelectItem key={crop.id} value={crop.name}>
                          {crop.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scenario-region">Region</Label>
                  <Select defaultValue="Midwest">
                    <SelectTrigger id="scenario-region">
                      <SelectValue placeholder="Select region" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Midwest">Midwest</SelectItem>
                      <SelectItem value="Northeast">Northeast</SelectItem>
                      <SelectItem value="Southeast">Southeast</SelectItem>
                      <SelectItem value="Southwest">Southwest</SelectItem>
                      <SelectItem value="West">West</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scenario-irrigation">Irrigation Method</Label>
                  <Select defaultValue="Drip Irrigation">
                    <SelectTrigger id="scenario-irrigation">
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      {irrigationMethods.map(method => (
                        <SelectItem key={method.id} value={method.name}>
                          {method.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                <div className="space-y-4">
                  <h3 className="font-semibold">Climate Scenarios</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-blue-100 text-blue-600 p-2 rounded-lg mr-3">
                          <i className="ri-sun-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Current Conditions</h4>
                          <p className="text-xs text-neutral-500">Baseline scenario with existing climate patterns</p>
                        </div>
                      </div>
                      <Badge>Selected</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-amber-100 text-amber-600 p-2 rounded-lg mr-3">
                          <i className="ri-temp-hot-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Warming Scenario (+2°C)</h4>
                          <p className="text-xs text-neutral-500">Higher temperatures, increased evaporation</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Select</Button>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-blue-100 text-blue-600 p-2 rounded-lg mr-3">
                          <i className="ri-rainy-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Increased Precipitation (+15%)</h4>
                          <p className="text-xs text-neutral-500">More rainfall, potential flooding risk</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Select</Button>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-red-100 text-red-600 p-2 rounded-lg mr-3">
                          <i className="ri-drought-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Drought Conditions (-25% rainfall)</h4>
                          <p className="text-xs text-neutral-500">Reduced precipitation, water stress</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Select</Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Management Practices</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-green-100 text-green-600 p-2 rounded-lg mr-3">
                          <i className="ri-seedling-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Standard Practices</h4>
                          <p className="text-xs text-neutral-500">Conventional irrigation and fertilization</p>
                        </div>
                      </div>
                      <Badge>Selected</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-green-100 text-green-600 p-2 rounded-lg mr-3">
                          <i className="ri-sensor-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Precision Agriculture</h4>
                          <p className="text-xs text-neutral-500">Soil moisture sensors, variable rate application</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Select</Button>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-green-100 text-green-600 p-2 rounded-lg mr-3">
                          <i className="ri-plant-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Cover Crops & Conservation</h4>
                          <p className="text-xs text-neutral-500">Improved soil health and water retention</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Select</Button>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer">
                      <div className="flex items-center">
                        <div className="bg-green-100 text-green-600 p-2 rounded-lg mr-3">
                          <i className="ri-recycle-line text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-medium">Water Recycling</h4>
                          <p className="text-xs text-neutral-500">Capturing and reusing irrigation runoff</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Select</Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-center pt-6">
                <Button className="w-full max-w-xs">
                  <i className="ri-line-chart-line mr-2"></i>
                  Run Scenario Analysis
                </Button>
              </div>

              <div className="bg-neutral-50 p-4 rounded-md border border-neutral-200">
                <h3 className="font-semibold mb-2">Expected Scenario Results</h3>
                <p className="text-neutral-600 text-sm">
                  With the current selections (Corn in Midwest using Drip Irrigation under current climate conditions
                  with standard practices), the model projects:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-3">
                  <div className="bg-white p-3 rounded-md border">
                    <p className="text-sm text-neutral-500">Water Usage</p>
                    <p className="text-lg font-semibold">550 mm</p>
                    <p className="text-xs text-neutral-500">Standard requirement</p>
                  </div>
                  <div className="bg-white p-3 rounded-md border">
                    <p className="text-sm text-neutral-500">Yield</p>
                    <p className="text-lg font-semibold">9.5 bushels/acre</p>
                    <p className="text-xs text-neutral-500">Expected with current inputs</p>
                  </div>
                  <div className="bg-white p-3 rounded-md border">
                    <p className="text-sm text-neutral-500">Water Efficiency</p>
                    <p className="text-lg font-semibold">High</p>
                    <p className="text-xs text-neutral-500">Drip irrigation optimizes delivery</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComparisonTools;