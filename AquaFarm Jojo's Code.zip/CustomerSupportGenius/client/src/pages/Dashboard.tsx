import { Button } from "@/components/ui/button";
import StatsCard from "@/components/dashboard/StatsCard";
import WaterUsageChart from "@/components/dashboard/WaterUsageChart";
import RegionalMap from "@/components/dashboard/RegionalMap";
import WaterCalculator from "@/components/dashboard/WaterCalculator";
import Recommendations from "@/components/dashboard/Recommendations";
import { useQuery } from "@tanstack/react-query";

interface DashboardStats {
  totalWaterUsage: {
    value: number;
    unit: string;
    change: string;
    changeDirection: 'up' | 'down';
  };
  efficiencyScore: {
    value: number;
    unit: string;
    change: string;
    changeDirection: 'up' | 'down';
  };
  activeCroplands: {
    value: number;
    unit: string;
    change: string;
    changeDirection: 'up' | 'down';
  };
  savingsPotential: {
    value: number;
    unit: string;
    percentage: string;
  };
}

const Dashboard = () => {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard-stats'],
  });

  return (
    <div className="bg-gradient-to-r from-blue-100 to-teal-100"> {/* Added background gradient */}
      {/* Page Title */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-neutral-900">Indian Agricultural Water Footprint Dashboard</h2>
          {/* Removed Print Button as it's considered non-functional in the user request */}
        </div>
        <p className="mt-1 text-sm text-neutral-500">
          View and analyze water usage across your Indian farming operations - Kharif and Rabi season analytics
        </p>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {statsLoading ? (
          <>
            <div className="bg-white h-24 animate-pulse rounded-lg shadow"></div>
            <div className="bg-white h-24 animate-pulse rounded-lg shadow"></div>
            <div className="bg-white h-24 animate-pulse rounded-lg shadow"></div>
            <div className="bg-white h-24 animate-pulse rounded-lg shadow"></div>
          </>
        ) : (
          <>
            <StatsCard
              title="Total Water Usage"
              value={stats?.totalWaterUsage.value || 0}
              valueUnit={` ${stats?.totalWaterUsage.unit || 'm³'}`}
              change={stats?.totalWaterUsage.change || '0'}
              changeDirection={stats?.totalWaterUsage.changeDirection || 'neutral'}
              icon="ri-water-flash-line"
              iconBgColor="bg-primary-light"
              trend={{ value: 12, label: "vs last month" }} // Added trend from the changes
            />

            <StatsCard
              title="Efficiency Score"
              value={stats?.efficiencyScore.value || 0}
              valueUnit={stats?.efficiencyScore.unit || '/100'}
              change={stats?.efficiencyScore.change || '0'}
              changeDirection={stats?.efficiencyScore.changeDirection || 'neutral'}
              icon="ri-scales-3-line"
              iconBgColor="bg-secondary-light"
              trend={{ value: 8, label: "improvement" }} // Added trend from the changes
            />

            <StatsCard
              title="Active Croplands"
              value={stats?.activeCroplands.value || 0}
              valueUnit={` ${stats?.activeCroplands.unit || 'hectares'}`}
              change={stats?.activeCroplands.change || '0'}
              changeDirection={stats?.activeCroplands.changeDirection || 'neutral'}
              icon="ri-plant-line"
              iconBgColor="bg-accent-light"
            />

            <StatsCard
              title="Savings Potential"
              value={stats?.savingsPotential.value || 0}
              valueUnit={` ${stats?.savingsPotential.unit || 'm³'}`}
              icon="ri-recycle-line"
              iconBgColor="bg-warning"
              trend={{ value: 15, label: "increase" }} // Added trend from the changes
            />
          </>
        )}
      </div>

      {/* Main Dashboard Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          <WaterUsageChart />
          <RegionalMap />
        </div>
        
        {/* Right Column */}
        <div className="space-y-6">
          <WaterCalculator />
          <Recommendations />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;