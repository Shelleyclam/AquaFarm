import { useState } from "react";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

interface DataSource {
  id: number;
  name: string;
  type: string;
  status: 'active' | 'inactive' | 'error';
  lastUpdate: string;
  description: string;
}

const dataSources: DataSource[] = [
  {
    id: 1,
    name: "Indian Meteorological Department (IMD)",
    type: "API Integration",
    status: "active",
    lastUpdate: "2025-04-10",
    description: "Weather and rainfall data from the Indian Meteorological Department"
  },
  {
    id: 2,
    name: "Soil Health Card Database",
    type: "API Integration",
    status: "active",
    lastUpdate: "2025-04-12",
    description: "Soil quality and nutrient data from the National Soil Health Program"
  },
  {
    id: 3,
    name: "ISRO RISAT Satellite",
    type: "API Integration",
    status: "inactive",
    lastUpdate: "2025-03-30",
    description: "Soil moisture and crop health data from ISRO's RISAT satellite"
  },
  {
    id: 4,
    name: "Krishi Vigyan Kendra Sensors",
    type: "Sensor Integration",
    status: "error",
    lastUpdate: "2025-04-05",
    description: "Farm-level soil moisture and weather sensors installed with KVK support"
  },
  {
    id: 5,
    name: "Central Water Commission",
    type: "API Integration",
    status: "active",
    lastUpdate: "2025-04-11",
    description: "Reservoir levels and river basin water availability data for irrigation planning"
  },
  {
    id: 6,
    name: "ICAR Crop Varieties Database",
    type: "API Integration",
    status: "active",
    lastUpdate: "2025-04-09",
    description: "Crop variety data for different agro-climatic zones from Indian Council of Agricultural Research"
  },
  {
    id: 7,
    name: "National Remote Sensing Centre",
    type: "API Integration",
    status: "active",
    lastUpdate: "2025-04-08",
    description: "Remote sensing data for crop acreage, vegetation indices, and land use patterns"
  }
];

const DataSources = () => {
  const [isAddSourceDialogOpen, setIsAddSourceDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  
  const filteredSources = dataSources.filter(source => 
    source.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    source.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    source.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-neutral-900">Data Sources</h2>
        <Dialog open={isAddSourceDialogOpen} onOpenChange={setIsAddSourceDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <i className="ri-add-line mr-2"></i>
              Add Data Source
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add New Data Source</DialogTitle>
              <DialogDescription>
                Connect a new data source to your water footprint dashboard
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input id="name" className="col-span-3" placeholder="USDA Crop Data" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="type" className="text-right">
                  Source Type
                </Label>
                <Input id="type" className="col-span-3" placeholder="API, Sensor, File Upload" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="connection" className="text-right">
                  Connection URL
                </Label>
                <Input id="connection" className="col-span-3" placeholder="https://api.example.com/data" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Description
                </Label>
                <Input id="description" className="col-span-3" placeholder="Description of this data source" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="active" className="text-right">
                  Active
                </Label>
                <div className="flex items-center space-x-2">
                  <Switch id="active" defaultChecked />
                  <Label htmlFor="active">Enable this data source</Label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={() => setIsAddSourceDialogOpen(false)}>Save Source</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-4 border-b border-neutral-200">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center space-y-3 sm:space-y-0">
            <Tabs defaultValue="all" className="w-full sm:w-auto">
              <TabsList>
                <TabsTrigger value="all">All Sources</TabsTrigger>
                <TabsTrigger value="api">API</TabsTrigger>
                <TabsTrigger value="sensor">Sensors</TabsTrigger>
                <TabsTrigger value="upload">Uploads</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="relative">
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400"></i>
              <Input 
                className="pl-10 w-full sm:w-64" 
                placeholder="Search data sources..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
        
        <div className="divide-y divide-neutral-200">
          {filteredSources.length > 0 ? (
            filteredSources.map((source) => (
              <div key={source.id} className="p-4 hover:bg-neutral-50 transition-colors">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium text-lg">{source.name}</h3>
                      <Badge 
                        className={`ml-3 ${
                          source.status === 'active' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 
                          source.status === 'inactive' ? 'bg-neutral-100 text-neutral-800 hover:bg-neutral-100' : 
                          'bg-red-100 text-red-800 hover:bg-red-100'
                        }`}
                      >
                        {source.status === 'active' ? 'Active' : 
                         source.status === 'inactive' ? 'Inactive' : 'Error'}
                      </Badge>
                    </div>
                    <p className="text-neutral-500 mt-1">{source.description}</p>
                    <div className="flex items-center mt-2 text-sm text-neutral-500">
                      <span className="flex items-center">
                        <i className="ri-information-line mr-1"></i> {source.type}
                      </span>
                      <span className="mx-2">•</span>
                      <span className="flex items-center">
                        <i className="ri-time-line mr-1"></i> Last updated: {source.lastUpdate}
                      </span>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <i className="ri-settings-line mr-1"></i> Configure
                    </Button>
                    <Button variant="outline" size="sm">
                      <i className="ri-refresh-line mr-1"></i> Refresh
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center">
              <i className="ri-search-line text-3xl text-neutral-400 mb-2"></i>
              <p className="text-neutral-500">No data sources found matching your search criteria.</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Connect External Data</CardTitle>
            <CardDescription>Import data from various sources to enhance your analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer transition-colors">
                <div className="bg-blue-100 text-blue-600 p-2 rounded-lg mr-3">
                  <i className="ri-database-2-line text-xl"></i>
                </div>
                <div>
                  <h4 className="font-medium">IMD Weather API</h4>
                  <p className="text-sm text-neutral-500">Connect to Indian Meteorological Department data</p>
                </div>
              </div>
              <div className="flex items-center p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer transition-colors">
                <div className="bg-green-100 text-green-600 p-2 rounded-lg mr-3">
                  <i className="ri-file-excel-line text-xl"></i>
                </div>
                <div>
                  <h4 className="font-medium">Local KVK Data Import</h4>
                  <p className="text-sm text-neutral-500">Import data from local Krishi Vigyan Kendra</p>
                </div>
              </div>
              <div className="flex items-center p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer transition-colors">
                <div className="bg-purple-100 text-purple-600 p-2 rounded-lg mr-3">
                  <i className="ri-device-line text-xl"></i>
                </div>
                <div>
                  <h4 className="font-medium">Smartphone Weather Data</h4>
                  <p className="text-sm text-neutral-500">Use KisanMitra app data from farmer smartphones</p>
                </div>
              </div>
              <div className="flex items-center p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer transition-colors">
                <div className="bg-amber-100 text-amber-600 p-2 rounded-lg mr-3">
                  <i className="ri-earth-line text-xl"></i>
                </div>
                <div>
                  <h4 className="font-medium">ISRO BHUVAN Portal</h4>
                  <p className="text-sm text-neutral-500">Geospatial data from ISRO's BHUVAN platform</p>
                </div>
              </div>
              <div className="flex items-center p-3 border rounded-lg hover:bg-neutral-50 cursor-pointer transition-colors">
                <div className="bg-red-100 text-red-600 p-2 rounded-lg mr-3">
                  <i className="ri-cloud-line text-xl"></i>
                </div>
                <div>
                  <h4 className="font-medium">India WRIS Portal</h4>
                  <p className="text-sm text-neutral-500">Water Resource Information System data</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Data Source Health</CardTitle>
            <CardDescription>Monitor the status of your connected data sources</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Active Sources</span>
                <span className="font-semibold">{dataSources.filter(s => s.status === 'active').length}/{dataSources.length}</span>
              </div>
              <div className="w-full h-2 bg-neutral-100 rounded-full overflow-hidden">
                <div 
                  className="bg-primary h-full" 
                  style={{ width: `${(dataSources.filter(s => s.status === 'active').length / dataSources.length) * 100}%` }}
                ></div>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-2">
                <div className="text-center p-2 bg-neutral-50 rounded-lg">
                  <div className="text-green-500 font-semibold">{dataSources.filter(s => s.status === 'active').length}</div>
                  <div className="text-xs text-neutral-500">Active</div>
                </div>
                <div className="text-center p-2 bg-neutral-50 rounded-lg">
                  <div className="text-neutral-500 font-semibold">{dataSources.filter(s => s.status === 'inactive').length}</div>
                  <div className="text-xs text-neutral-500">Inactive</div>
                </div>
                <div className="text-center p-2 bg-neutral-50 rounded-lg">
                  <div className="text-red-500 font-semibold">{dataSources.filter(s => s.status === 'error').length}</div>
                  <div className="text-xs text-neutral-500">Error</div>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                <i className="ri-refresh-line mr-2"></i> Refresh All Sources
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DataSources;
