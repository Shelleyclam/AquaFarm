import { useState, useEffect } from "react";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle
} from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from 'recharts';

// Sample data for regional analysis (India specific)
const regions = [
  { id: 1, name: "Indo-Gangetic Plains", shortName: "IGP", climateZone: "Subtropical", avgTemp: 24.5, avgRainfall: 800 },
  { id: 2, name: "Deccan Plateau", shortName: "DP", climateZone: "Semi-Arid", avgTemp: 26.2, avgRainfall: 600 },
  { id: 3, name: "Western Coastal Plains", shortName: "WCP", climateZone: "Tropical", avgTemp: 27.5, avgRainfall: 2500 },
  { id: 4, name: "Eastern Coastal Plains", shortName: "ECP", climateZone: "Tropical", avgTemp: 28.3, avgRainfall: 1200 },
  { id: 5, name: "Himalayan Region", shortName: "HR", climateZone: "Alpine", avgTemp: 15.4, avgRainfall: 1600 },
  { id: 6, name: "Central Highlands", shortName: "CH", climateZone: "Semi-Arid", avgTemp: 25.8, avgRainfall: 500 },
  { id: 7, name: "Thar Desert", shortName: "TD", climateZone: "Arid", avgTemp: 28.9, avgRainfall: 150 },
  { id: 8, name: "North-Eastern Region", shortName: "NER", climateZone: "Subtropical", avgTemp: 22.7, avgRainfall: 2000 },
];

const regionalWaterUsage = [
  { region: "Indo-Gangetic Plains", cropland: 48500, irrigation: 35200, total: 42300, efficiency: 78 },
  { region: "Deccan Plateau", cropland: 32800, irrigation: 24100, total: 28400, efficiency: 72 },
  { region: "Western Coastal Plains", cropland: 15200, irrigation: 9800, total: 12500, efficiency: 85 },
  { region: "Eastern Coastal Plains", cropland: 18600, irrigation: 12400, total: 15200, efficiency: 80 },
  { region: "Himalayan Region", cropland: 7400, irrigation: 3800, total: 4700, efficiency: 92 },
  { region: "Central Highlands", cropland: 25400, irrigation: 18800, total: 22700, efficiency: 65 },
  { region: "Thar Desert", cropland: 6400, irrigation: 5800, total: 6200, efficiency: 58 },
  { region: "North-Eastern Region", cropland: 12400, irrigation: 6800, total: 8700, efficiency: 88 },
];

// Monthly rainfall data (based on typical Indian monsoon patterns)
const monthlyRainfall = {
  "Indo-Gangetic Plains": [10, 15, 20, 30, 50, 150, 250, 220, 150, 40, 10, 5],
  "Deccan Plateau": [5, 10, 15, 20, 30, 120, 180, 160, 120, 50, 20, 10],
  "Western Coastal Plains": [5, 5, 10, 15, 50, 650, 850, 650, 250, 80, 30, 10],
  "Eastern Coastal Plains": [15, 20, 30, 40, 60, 150, 250, 220, 200, 150, 50, 20],
  "Himalayan Region": [60, 80, 100, 120, 150, 200, 300, 280, 180, 80, 30, 20],
  "Central Highlands": [5, 10, 15, 25, 30, 100, 150, 140, 100, 30, 10, 5],
  "Thar Desert": [2, 5, 8, 10, 15, 30, 40, 35, 20, 5, 2, 1],
  "North-Eastern Region": [30, 50, 100, 180, 300, 450, 500, 450, 350, 200, 80, 40],
};

// Crop distribution by region in India
const cropsByRegion = {
  "Indo-Gangetic Plains": [
    { name: "Rice", percentage: 35 },
    { name: "Wheat", percentage: 40 },
    { name: "Maize", percentage: 15 },
    { name: "Other", percentage: 10 },
  ],
  "Deccan Plateau": [
    { name: "Cotton", percentage: 30 },
    { name: "Pulses", percentage: 25 },
    { name: "Jowar", percentage: 25 },
    { name: "Other", percentage: 20 },
  ],
  "Western Coastal Plains": [
    { name: "Rice", percentage: 30 },
    { name: "Coconut", percentage: 25 },
    { name: "Sugarcane", percentage: 25 },
    { name: "Other", percentage: 20 },
  ],
  "Eastern Coastal Plains": [
    { name: "Rice", percentage: 45 },
    { name: "Sugarcane", percentage: 20 },
    { name: "Vegetables", percentage: 20 },
    { name: "Other", percentage: 15 },
  ],
  "Himalayan Region": [
    { name: "Rice", percentage: 20 },
    { name: "Wheat", percentage: 15 },
    { name: "Fruits", percentage: 45 },
    { name: "Other", percentage: 20 },
  ],
  "Central Highlands": [
    { name: "Cotton", percentage: 30 },
    { name: "Wheat", percentage: 20 },
    { name: "Soybeans", percentage: 25 },
    { name: "Other", percentage: 25 },
  ],
  "Thar Desert": [
    { name: "Bajra", percentage: 45 },
    { name: "Pulses", percentage: 20 },
    { name: "Cotton", percentage: 15 },
    { name: "Other", percentage: 20 },
  ],
  "North-Eastern Region": [
    { name: "Rice", percentage: 55 },
    { name: "Tea", percentage: 25 },
    { name: "Fruits", percentage: 10 },
    { name: "Other", percentage: 10 },
  ],
};

const futureProjections = {
  "2025": [28350, 15600, 8650, 4100],
  "2026": [27100, 15400, 7900, 3800],
  "2027": [25900, 15200, 7200, 3500],
  "2028": [24800, 15000, 6550, 3250],
  "2029": [23800, 14800, 5950, 3050],
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const RegionalAnalysis = () => {
  const [selectedRegion, setSelectedRegion] = useState("Indo-Gangetic Plains");
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  const [cropData, setCropData] = useState<any[]>([]);

  useEffect(() => {
    // Convert monthly rainfall data for the selected region into chart format
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const rainfallData = monthlyRainfall[selectedRegion as keyof typeof monthlyRainfall];

    setMonthlyData(months.map((month, i) => ({ 
      name: month, 
      rainfall: rainfallData[i],
    })));

    // Set crop data for the selected region
    setCropData(cropsByRegion[selectedRegion as keyof typeof cropsByRegion]);
  }, [selectedRegion]);

  const selectedRegionData = regionalWaterUsage.find(r => r.region === selectedRegion);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-neutral-900">Regional Analysis</h2>
        <div className="flex space-x-2">
          <div className="w-64">
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger>
                <SelectValue placeholder="Select region" />
              </SelectTrigger>
              <SelectContent>
                {regions.map((region) => (
                  <SelectItem key={region.id} value={region.name}>
                    {region.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" onClick={() => window.print()}>
            <i className="ri-printer-line mr-2"></i>
            Print Report
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {selectedRegionData && (
          <>
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center">
                  <span className="text-sm text-neutral-500">Cropland Area</span>
                  <span className="text-3xl font-bold text-neutral-900 mt-1">
                    {selectedRegionData.cropland.toLocaleString()} ha
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center">
                  <span className="text-sm text-neutral-500">Water Usage</span>
                  <span className="text-3xl font-bold text-neutral-900 mt-1">
                    {selectedRegionData.total.toLocaleString()} m³
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center">
                  <span className="text-sm text-neutral-500">Efficiency Score</span>
                  <div className="flex items-center mt-1">
                    <span className="text-3xl font-bold text-neutral-900">
                      {selectedRegionData.efficiency}/100
                    </span>
                    <Badge
                      className={`ml-2 ${
                        selectedRegionData.efficiency >= 85 ? 'bg-green-100 text-green-800 hover:bg-green-100' :
                        selectedRegionData.efficiency >= 70 ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' :
                        'bg-red-100 text-red-800 hover:bg-red-100'
                      }`}
                    >
                      {selectedRegionData.efficiency >= 85 ? 'Excellent' :
                       selectedRegionData.efficiency >= 70 ? 'Good' :
                       'Needs Improvement'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Regional Profile: {selectedRegion}</CardTitle>
          <CardDescription>
            {regions.find(r => r.name === selectedRegion)?.climateZone} climate zone with {
              regions.find(r => r.name === selectedRegion)?.avgTemp
            }°C average temperature and {
              regions.find(r => r.name === selectedRegion)?.avgRainfall
            } mm annual rainfall
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="rainfall" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="rainfall">
                <i className="ri-cloud-line mr-2"></i>
                Rainfall
              </TabsTrigger>
              <TabsTrigger value="crops">
                <i className="ri-plant-line mr-2"></i>
                Crops
              </TabsTrigger>
              <TabsTrigger value="comparison">
                <i className="ri-bar-chart-grouped-line mr-2"></i>
                Regional Comparison
              </TabsTrigger>
            </TabsList>

            <TabsContent value="rainfall" className="space-y-4">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={monthlyData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value} mm`, 'Rainfall']} />
                    <Legend />
                    <Line type="monotone" dataKey="rainfall" stroke="#3b82f6" activeDot={{ r: 8 }} name="Rainfall (mm)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-neutral-50 p-4 rounded-md border border-neutral-200">
                <h3 className="font-semibold mb-2">Annual Rainfall Distribution</h3>
                <p className="text-neutral-600">
                  The {selectedRegion} region receives an average of {
                    regions.find(r => r.name === selectedRegion)?.avgRainfall
                  } mm of rainfall annually, with precipitation primarily occurring during {
                    selectedRegion === "Indo-Gangetic Plains" ? "the monsoon months (June-September)" :
                    selectedRegion === "Deccan Plateau" ? "the southwest monsoon period" :
                    selectedRegion === "Western Coastal Plains" ? "the intense southwest monsoon season" :
                    selectedRegion === "Eastern Coastal Plains" ? "both southwest and northeast monsoons" :
                    selectedRegion === "Himalayan Region" ? "the summer and monsoon months" :
                    selectedRegion === "Central Highlands" ? "the mid to late monsoon period" :
                    selectedRegion === "Thar Desert" ? "the brief monsoon period in July-August" :
                    selectedRegion === "North-Eastern Region" ? "the prolonged monsoon season (May-September)" :
                    "the monsoon season"
                  }.
                </p>
              </div>
            </TabsContent>

            <TabsContent value="crops" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={cropData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="percentage"
                        nameKey="name"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {cropData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Crop Distribution</h3>
                  <p className="text-neutral-600">
                    The {selectedRegion} region primarily grows {
                      cropData.sort((a, b) => b.percentage - a.percentage)[0]?.name
                    } ({
                      cropData.sort((a, b) => b.percentage - a.percentage)[0]?.percentage
                    }% of cultivated land), followed by {
                      cropData.sort((a, b) => b.percentage - a.percentage)[1]?.name
                    } ({
                      cropData.sort((a, b) => b.percentage - a.percentage)[1]?.percentage
                    }%).
                  </p>

                  <h4 className="font-medium mt-4">Water Requirements</h4>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Crop</TableHead>
                          <TableHead>Water Requirement</TableHead>
                          <TableHead className="text-right">Water Efficiency</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Rice</TableCell>
                          <TableCell>1200 mm</TableCell>
                          <TableCell className="text-right">
                            <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                              Low
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Wheat</TableCell>
                          <TableCell>450 mm</TableCell>
                          <TableCell className="text-right">
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                              High
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Sugarcane</TableCell>
                          <TableCell>1500 mm</TableCell>
                          <TableCell className="text-right">
                            <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                              Low
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Cotton</TableCell>
                          <TableCell>700 mm</TableCell>
                          <TableCell className="text-right">
                            <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                              Medium
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Pulses</TableCell>
                          <TableCell>350 mm</TableCell>
                          <TableCell className="text-right">
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                              High
                            </Badge>
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="comparison">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={regionalWaterUsage}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="region" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="irrigation" fill="#3b82f6" name="Irrigation (m³)" />
                    <Bar dataKey="total" fill="#10b981" name="Total (m³)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="space-y-2">
                  <h3 className="font-semibold">Efficiency by Region</h3>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Region</TableHead>
                          <TableHead>Efficiency Score</TableHead>
                          <TableHead className="text-right">Rating</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {regionalWaterUsage.map((region) => (
                          <TableRow key={region.region}>
                            <TableCell className={`font-medium ${region.region === selectedRegion ? 'bg-neutral-50' : ''}`}>
                              {region.region}
                            </TableCell>
                            <TableCell className={region.region === selectedRegion ? 'bg-neutral-50' : ''}>
                              {region.efficiency}/100
                            </TableCell>
                            <TableCell className={`text-right ${region.region === selectedRegion ? 'bg-neutral-50' : ''}`}>
                              <Badge
                                className={
                                  region.efficiency >= 85 ? 'bg-green-100 text-green-800 hover:bg-green-100' :
                                  region.efficiency >= 70 ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' :
                                  'bg-red-100 text-red-800 hover:bg-red-100'
                                }
                              >
                                {region.efficiency >= 85 ? 'Excellent' :
                                 region.efficiency >= 70 ? 'Good' :
                                 'Needs Improvement'}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Climate Comparison</h3>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Region</TableHead>
                          <TableHead>Climate Zone</TableHead>
                          <TableHead>Avg. Temp (°C)</TableHead>
                          <TableHead className="text-right">Annual Rainfall (mm)</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {regions.map((region) => (
                          <TableRow key={region.id}>
                            <TableCell className={`font-medium ${region.name === selectedRegion ? 'bg-neutral-50' : ''}`}>
                              {region.name}
                            </TableCell>
                            <TableCell className={region.name === selectedRegion ? 'bg-neutral-50' : ''}>
                              {region.climateZone}
                            </TableCell>
                            <TableCell className={region.name === selectedRegion ? 'bg-neutral-50' : ''}>
                              {region.avgTemp}
                            </TableCell>
                            <TableCell className={`text-right ${region.name === selectedRegion ? 'bg-neutral-50' : ''}`}>
                              {region.avgRainfall}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Future Projections</CardTitle>
          <CardDescription>Water usage and rainfall projections for the next 5 years</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={Object.keys(futureProjections).map(year => ({
                  year,
                  total: futureProjections[year as keyof typeof futureProjections][0],
                  irrigation: futureProjections[year as keyof typeof futureProjections][1],
                  rainfall: futureProjections[year as keyof typeof futureProjections][2],
                  savings: futureProjections[year as keyof typeof futureProjections][3],
                }))}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="total" fill="#3b82f6" name="Total Usage (m³)" />
                <Bar dataKey="irrigation" fill="#10b981" name="Irrigation (m³)" />
                <Bar dataKey="rainfall" fill="#6366f1" name="Rainfall Contribution (m³)" />
                <Bar dataKey="savings" fill="#f59e0b" name="Projected Savings (m³)" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
            <h3 className="font-semibold text-lg text-blue-800 mb-2">Projection Insights for Indian Agriculture</h3>
            <p className="text-blue-700 mb-3">
              Based on current trends, monsoon forecasts, and planned water-efficient technologies, we project an 18% reduction in water usage 
              over the next 5 years, while improving crop yields through better water management practices.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white p-3 rounded-md border border-blue-100">
                <p className="text-sm text-blue-600">Total Water Reduction</p>
                <p className="text-lg font-semibold text-blue-800">5,103 m³</p>
                <p className="text-xs text-blue-500">18% of current usage</p>
              </div>
              <div className="bg-white p-3 rounded-md border border-blue-100">
                <p className="text-sm text-blue-600">Yield Improvement</p>
                <p className="text-lg font-semibold text-blue-800">+15%</p>
                <p className="text-xs text-blue-500">Through micro-irrigation</p>
              </div>
              <div className="bg-white p-3 rounded-md border border-blue-100">
                <p className="text-sm text-blue-600">Cost Savings</p>
                <p className="text-lg font-semibold text-blue-800">₹11,25,000</p>
                <p className="text-xs text-blue-500">Over 5 years</p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t pt-4 text-neutral-500 text-sm">
          <span>Data sources: India Meteorological Department (IMD), Indian Agricultural Research Institute (IARI), Central Water Commission, and National Water Informatics Centre</span>
        </CardFooter>
      </Card>
    </div>
  );
};

export default RegionalAnalysis;