import { useState } from "react";
import jsPDF from "jspdf";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from "@/components/ui/select";
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

// Sample data for reports
const waterUsageByMonth = [
  { name: 'Jan', value: 2100 },
  { name: 'Feb', value: 1950 },
  { name: 'Mar', value: 2250 },
  { name: 'Apr', value: 2400 },
  { name: 'May', value: 2650 },
  { name: 'Jun', value: 2800 },
  { name: 'Jul', value: 2950 },
  { name: 'Aug', value: 2700 },
  { name: 'Sep', value: 2400 },
  { name: 'Oct', value: 2200 },
  { name: 'Nov', value: 2000 },
  { name: 'Dec', value: 1950 }
];

const waterUsageBySource = [
  { name: 'Canal Irrigation', value: 15200 },
  { name: 'Monsoon Rainfall', value: 8950 },
  { name: 'Groundwater', value: 6300 },
  { name: 'Rainwater Harvesting', value: 2800 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const efficiencyByRegion = [
  { region: 'Northern Plains', score: 85, savings: 1200 },
  { region: 'Western Ghats', score: 92, savings: 1850 },
  { region: 'Deccan Plateau', score: 78, savings: 950 },
  { region: 'Indo-Gangetic Plain', score: 73, savings: 1050 },
  { region: 'Eastern Coastal', score: 65, savings: 750 },
];

const efficienctByCrop = [
  { crop: 'Rice', score: 58, usage: 11500 },
  { crop: 'Wheat', score: 76, usage: 4200 },
  { crop: 'Sugarcane', score: 62, usage: 9200 },
  { crop: 'Cotton', score: 71, usage: 7100 },
  { crop: 'Pulses', score: 88, usage: 3500 },
];

const savedReports = [
  { id: 1, name: 'Q1 Water Usage Summary', type: 'Water Usage', createdDate: '2025-04-01', status: 'completed' },
  { id: 2, name: 'Western Ghats Region Analysis', type: 'Regional', createdDate: '2025-03-15', status: 'completed' },
  { id: 3, name: 'Rice Irrigation Efficiency', type: 'Crop Analysis', createdDate: '2025-03-22', status: 'completed' },
  { id: 4, name: 'Post-Monsoon Water Management', type: 'Seasonal', createdDate: '2025-04-10', status: 'pending' },
  { id: 5, name: 'Groundwater Conservation Report', type: 'Conservation', createdDate: '2025-04-02', status: 'completed' },
  { id: 6, name: 'Sugarcane Drip Irrigation Study', type: 'Crop Analysis', createdDate: '2025-03-28', status: 'completed' },
];

const Reports = () => {
  const [reportType, setReportType] = useState('usage');
  const [dateRange, setDateRange] = useState('last30');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredReports = savedReports.filter(report => 
    report.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    report.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-neutral-900">Reports</h2>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => window.print()}>
            <i className="ri-printer-line mr-2"></i>
            Print Report
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="w-full justify-start mb-6">
          <TabsTrigger value="overview" className="flex items-center">
            <i className="ri-bar-chart-2-line mr-2"></i> Overview
          </TabsTrigger>
          <TabsTrigger value="saved" className="flex items-center">
            <i className="ri-save-line mr-2"></i> Saved Reports
          </TabsTrigger>
          <TabsTrigger value="water-usage" className="flex items-center">
            <i className="ri-drop-line mr-2"></i> Water Usage
          </TabsTrigger>
          <TabsTrigger value="efficiency" className="flex items-center">
            <i className="ri-leaf-line mr-2"></i> Efficiency
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center">
            <i className="ri-time-line mr-2"></i> Scheduled
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Water Usage by Month</CardTitle>
                <CardDescription>Total water usage (cubic meters) for 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={waterUsageByMonth}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value} m³`, 'Water Usage']} />
                      <Bar dataKey="value" fill="#3b82f6" name="Water Usage (m³)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Water Source Distribution</CardTitle>
                <CardDescription>Water sources used for irrigation in 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={waterUsageBySource}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {waterUsageBySource.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} m³`, 'Volume']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Efficiency by Region</CardTitle>
              <CardDescription>Regional water efficiency scores and potential savings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Region</TableHead>
                      <TableHead>Efficiency Score</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead className="text-right">Potential Savings (m³)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {efficiencyByRegion.map((region) => (
                      <TableRow key={region.region}>
                        <TableCell className="font-medium">{region.region}</TableCell>
                        <TableCell>{region.score}/100</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              region.score >= 85 ? 'bg-green-100 text-green-800 hover:bg-green-100' :
                              region.score >= 70 ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' :
                              'bg-red-100 text-red-800 hover:bg-red-100'
                            }
                          >
                            {region.score >= 85 ? 'Excellent' :
                             region.score >= 70 ? 'Good' :
                             'Needs Improvement'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">{region.savings.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Quick Report Generator</CardTitle>
              <CardDescription>Create custom reports based on your data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="report-type">Report Type</Label>
                    <Select value={reportType} onValueChange={setReportType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="usage">Water Usage</SelectItem>
                        <SelectItem value="efficiency">Efficiency</SelectItem>
                        <SelectItem value="savings">Water Savings</SelectItem>
                        <SelectItem value="comparison">Comparison</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="date-range">Date Range</Label>
                    <Select value={dateRange} onValueChange={setDateRange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="last7">Last 7 days</SelectItem>
                        <SelectItem value="last30">Last 30 days</SelectItem>
                        <SelectItem value="last90">Last 90 days</SelectItem>
                        <SelectItem value="year">This year</SelectItem>
                        <SelectItem value="custom">Custom range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="format">Export Format</Label>
                    <Select defaultValue="pdf">
                      <SelectTrigger>
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF Document</SelectItem>
                        <SelectItem value="xlsx">Excel Spreadsheet</SelectItem>
                        <SelectItem value="csv">CSV File</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <Button variant="outline" className="w-full">Preview Report</Button>
                  <Button className="w-full">Generate Report</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="saved" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between sm:items-center space-y-3 sm:space-y-0">
                <CardTitle>Saved Reports</CardTitle>
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400"></i>
                  <Input 
                    className="pl-10 w-full sm:w-64" 
                    placeholder="Search reports..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Report Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Created Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReports.length > 0 ? (
                      filteredReports.map((report) => (
                        <TableRow key={report.id}>
                          <TableCell className="font-medium">{report.name}</TableCell>
                          <TableCell>{report.type}</TableCell>
                          <TableCell>{report.createdDate}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                report.status === 'completed' ? 'bg-green-100 text-green-800 hover:bg-green-100' :
                                'bg-amber-100 text-amber-800 hover:bg-amber-100'
                              }
                            >
                              {report.status === 'completed' ? 'Completed' : 'Pending'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button variant="outline" size="sm">
                                <i className="ri-eye-line"></i>
                              </Button>
                              <Button variant="outline" size="sm">
                                <i className="ri-download-line"></i>
                              </Button>
                              <Button variant="outline" size="sm">
                                <i className="ri-delete-bin-line"></i>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6 text-neutral-500">
                          No reports found matching your search criteria.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="water-usage" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Water Usage Analysis</CardTitle>
              <CardDescription>In-depth analysis of water consumption patterns</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-neutral-50 border border-neutral-200 rounded-md p-4">
                <h3 className="font-semibold text-lg mb-2">Summary</h3>
                <p className="text-neutral-600 mb-3">
                  Total water usage for 2025 (YTD): <span className="font-semibold">28,350 m³</span>
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-white p-3 rounded-md border">
                    <p className="text-sm text-neutral-500">Compared to Previous Year</p>
                    <p className="text-lg font-semibold text-green-600">-15.2%</p>
                  </div>
                  <div className="bg-white p-3 rounded-md border">
                    <p className="text-sm text-neutral-500">Efficiency Score</p>
                    <p className="text-lg font-semibold">85/100</p>
                  </div>
                  <div className="bg-white p-3 rounded-md border">
                    <p className="text-sm text-neutral-500">Potential Savings</p>
                    <p className="text-lg font-semibold text-blue-600">4,250 m³</p>
                  </div>
                </div>
              </div>
              
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={waterUsageByMonth}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value} m³`, 'Water Usage']} />
                    <Legend />
                    <Bar dataKey="value" fill="#3b82f6" name="Water Usage (m³)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-semibold">Water Usage by Crop</h3>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Crop</TableHead>
                        <TableHead>Total Usage (m³)</TableHead>
                        <TableHead>Efficiency Score</TableHead>
                        <TableHead className="text-right">Percentage of Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {efficienctByCrop.map((crop) => (
                        <TableRow key={crop.crop}>
                          <TableCell className="font-medium">{crop.crop}</TableCell>
                          <TableCell>{crop.usage.toLocaleString()}</TableCell>
                          <TableCell>{crop.score}/100</TableCell>
                          <TableCell className="text-right">
                            {Math.round(crop.usage / 33400 * 100)}%
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4 flex justify-between text-sm text-neutral-500">
              <p>Last updated: April 12, 2025</p>
              <p>Data source: Farm Sensors & Weather API</p>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="efficiency" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Water Efficiency Report</CardTitle>
              <CardDescription>Analysis of water usage efficiency and improvement opportunities</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Overall Efficiency</h3>
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-100 text-green-800 h-24 w-24 rounded-full flex items-center justify-center text-3xl font-bold">
                      85%
                    </div>
                    <div>
                      <p className="font-medium">Excellent</p>
                      <p className="text-sm text-neutral-500">15% higher than industry average</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Top Performing Areas</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <i className="ri-check-line text-green-600 mr-2"></i>
                        <span>Southeast region (92% efficiency)</span>
                      </li>
                      <li className="flex items-center">
                        <i className="ri-check-line text-green-600 mr-2"></i>
                        <span>Soybeans crops (88% efficiency)</span>
                      </li>
                      <li className="flex items-center">
                        <i className="ri-check-line text-green-600 mr-2"></i>
                        <span>Drip irrigation systems (90% efficiency)</span>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Improvement Opportunities</h3>
                  <div className="space-y-3">
                    <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
                      <h4 className="font-medium text-amber-800">Southwest Region</h4>
                      <p className="text-sm text-amber-700">
                        65% efficiency - Implement soil moisture sensors to optimize irrigation timing
                      </p>
                    </div>
                    <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
                      <h4 className="font-medium text-amber-800">Rice Cultivation</h4>
                      <p className="text-sm text-amber-700">
                        58% efficiency - Consider alternate wetting and drying technique
                      </p>
                    </div>
                    <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
                      <h4 className="font-medium text-amber-800">Flood Irrigation</h4>
                      <p className="text-sm text-amber-700">
                        50% efficiency - Transition to more efficient irrigation methods
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Savings Potential</h3>
                <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-blue-700">Annual Potential Savings</p>
                      <p className="text-2xl font-bold text-blue-700">4,250 m³</p>
                      <p className="text-sm text-blue-600">15% of current usage</p>
                    </div>
                    <div>
                      <p className="text-sm text-blue-700">Estimated Cost Savings</p>
                      <p className="text-2xl font-bold text-blue-700">$12,750</p>
                      <p className="text-sm text-blue-600">Based on current water rates</p>
                    </div>
                    <div>
                      <p className="text-sm text-blue-700">Implementation Timeframe</p>
                      <p className="text-2xl font-bold text-blue-700">3-6 months</p>
                      <p className="text-sm text-blue-600">For recommended changes</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full"
                onClick={() => {
                  const doc = new jsPDF();
                  doc.setFontSize(16);
                  doc.text("Water Efficiency Report", 20, 20);
                  
                  doc.setFontSize(12);
                  doc.text("Overall Efficiency: 85%", 20, 40);
                  doc.text("Top Performing Areas:", 20, 60);
                  doc.text("- Southeast region (92% efficiency)", 30, 70);
                  doc.text("- Soybeans crops (88% efficiency)", 30, 80);
                  doc.text("- Drip irrigation systems (90% efficiency)", 30, 90);
                  
                  doc.text("Improvement Opportunities:", 20, 110);
                  doc.text("- Southwest Region: 65% efficiency", 30, 120);
                  doc.text("- Rice Cultivation: 58% efficiency", 30, 130);
                  doc.text("- Flood Irrigation: 50% efficiency", 30, 140);
                  
                  doc.save("water-efficiency-report.pdf");
                }}
              >
                <i className="ri-file-pdf-line mr-2"></i>
                Download Detailed Efficiency Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="schedule" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Reports</CardTitle>
              <CardDescription>Set up automated reports to be generated and delivered on schedule</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="bg-white p-4 border rounded-lg hover:bg-neutral-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg">Weekly Water Usage Summary</h3>
                      <p className="text-neutral-500 text-sm">Automatically generated every Monday at 8:00 AM</p>
                      <div className="flex items-center mt-2 space-x-4">
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                          Active
                        </Badge>
                        <span className="text-sm text-neutral-500">
                          <i className="ri-mail-line mr-1"></i> Delivered via Email
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">Edit</Button>
                      <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        Disable
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white p-4 border rounded-lg hover:bg-neutral-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg">Monthly Efficiency Report</h3>
                      <p className="text-neutral-500 text-sm">Generated on the 1st of each month</p>
                      <div className="flex items-center mt-2 space-x-4">
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                          Active
                        </Badge>
                        <span className="text-sm text-neutral-500">
                          <i className="ri-mail-line mr-1"></i> Delivered via Email
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">Edit</Button>
                      <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        Disable
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white p-4 border rounded-lg hover:bg-neutral-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg">Quarterly Regional Analysis</h3>
                      <p className="text-neutral-500 text-sm">Generated on the first day of each quarter</p>
                      <div className="flex items-center mt-2 space-x-4">
                        <Badge className="bg-neutral-100 text-neutral-800 hover:bg-neutral-100">
                          Inactive
                        </Badge>
                        <span className="text-sm text-neutral-500">
                          <i className="ri-file-download-line mr-1"></i> Download Only
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">Edit</Button>
                      <Button variant="outline" size="sm" className="text-green-600 hover:text-green-700 hover:bg-green-50">
                        Enable
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <Button className="w-full">
                  <i className="ri-add-line mr-2"></i>
                  Create New Scheduled Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;
