import { useState } from "react";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { toast } from "@/hooks/use-toast";

const Settings = () => {
  const [units, setUnits] = useState("metric");
  const [userInfo, setUserInfo] = useState({
    name: "Rajesh Kumar",
    email: "rajesh.kumar@example.com",
    role: "Kisan (Farmer)",
    organization: "Krishna Agro Farms"
  });
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    weeklyReport: true,
    alerts: true
  });
  const [dataRefreshInterval, setDataRefreshInterval] = useState(15);
  const [theme, setTheme] = useState("system");
  const [dashboardPreferences, setDashboardPreferences] = useState({
    showWaterUsageChart: true,
    showRecommendations: true,
    showRegionalMap: true,
    showWeatherData: true
  });
  
  const handleUserInfoChange = (field: keyof typeof userInfo, value: string) => {
    setUserInfo(prev => ({ ...prev, [field]: value }));
  };
  
  const handleNotificationToggle = (field: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [field]: !prev[field] }));
  };
  
  const handleDashboardToggle = (field: keyof typeof dashboardPreferences) => {
    setDashboardPreferences(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully.",
    });
  };
  
  const handleResetDefaults = () => {
    // Reset form to defaults
    setUnits("metric");
    setDataRefreshInterval(15);
    setTheme("system");
    setDashboardPreferences({
      showWaterUsageChart: true,
      showRecommendations: true,
      showRegionalMap: true,
      showWeatherData: true
    });
    
    toast({
      title: "Settings reset",
      description: "Your settings have been reset to defaults.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-neutral-900">Settings</h2>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleResetDefaults}>
            Reset to Defaults
          </Button>
          <Button onClick={handleSaveSettings}>
            Save Changes
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="account" className="w-full">
        <TabsList className="w-full justify-start mb-6">
          <TabsTrigger value="account" className="flex items-center">
            <i className="ri-user-line mr-2"></i> Account
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex items-center">
            <i className="ri-eye-line mr-2"></i> Appearance
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center">
            <i className="ri-notification-line mr-2"></i> Notifications
          </TabsTrigger>
          <TabsTrigger value="dashboard" className="flex items-center">
            <i className="ri-dashboard-line mr-2"></i> Dashboard
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center">
            <i className="ri-database-line mr-2"></i> Data
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>Manage your account details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input 
                    id="name" 
                    value={userInfo.name} 
                    onChange={(e) => handleUserInfoChange('name', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={userInfo.email} 
                    onChange={(e) => handleUserInfoChange('email', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Input 
                    id="role" 
                    value={userInfo.role} 
                    onChange={(e) => handleUserInfoChange('role', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="organization">Organization</Label>
                  <Input 
                    id="organization" 
                    value={userInfo.organization} 
                    onChange={(e) => handleUserInfoChange('organization', e.target.value)} 
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-5">
              <p className="text-sm text-neutral-500">Last updated: April 12, 2025</p>
              <Button>Update Profile</Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Security</CardTitle>
              <CardDescription>Manage your password and security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="new-password">New Password</Label>
                  <Input id="new-password" type="password" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm New Password</Label>
                  <Input id="confirm-password" type="password" />
                </div>
              </div>
              <Separator className="my-2" />
              <div className="flex items-center justify-between">
                <div className="flex space-x-2 items-center">
                  <Switch id="two-factor" />
                  <Label htmlFor="two-factor">Enable Two-Factor Authentication</Label>
                </div>
                <Button variant="outline" size="sm">Set Up</Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Change Password</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Customize how the application looks for you</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Theme</Label>
                <RadioGroup
                  value={theme}
                  onValueChange={setTheme}
                  className="flex space-x-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light">Light</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark">Dark</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="system" id="system" />
                    <Label htmlFor="system">System</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label>Density</Label>
                <RadioGroup defaultValue="comfortable" className="flex space-x-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="compact" id="compact" />
                    <Label htmlFor="compact">Compact</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="comfortable" id="comfortable" />
                    <Label htmlFor="comfortable">Comfortable</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="spacious" id="spacious" />
                    <Label htmlFor="spacious">Spacious</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label>Font Size</Label>
                <RadioGroup defaultValue="medium" className="flex space-x-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="small" id="small" />
                    <Label htmlFor="small">Small</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="medium" id="medium" />
                    <Label htmlFor="medium">Medium</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="large" id="large" />
                    <Label htmlFor="large">Large</Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Accessibility</CardTitle>
              <CardDescription>Enhance your experience with accessibility features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="high-contrast">High Contrast Mode</Label>
                  <p className="text-sm text-neutral-500">Increase contrast for better visibility</p>
                </div>
                <Switch id="high-contrast" />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="reduce-motion">Reduce Motion</Label>
                  <p className="text-sm text-neutral-500">Minimize animations throughout the interface</p>
                </div>
                <Switch id="reduce-motion" />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="screen-reader">Screen Reader Optimizations</Label>
                  <p className="text-sm text-neutral-500">Enhance compatibility with screen readers</p>
                </div>
                <Switch id="screen-reader" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Manage how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="email-notifications">Email Notifications</Label>
                  <p className="text-sm text-neutral-500">Receive updates and alerts via email</p>
                </div>
                <Switch 
                  id="email-notifications" 
                  checked={notifications.email}
                  onCheckedChange={() => handleNotificationToggle('email')}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="push-notifications">Push Notifications</Label>
                  <p className="text-sm text-neutral-500">Receive notifications in your browser</p>
                </div>
                <Switch 
                  id="push-notifications" 
                  checked={notifications.push}
                  onCheckedChange={() => handleNotificationToggle('push')}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="weekly-report">Weekly Water Usage Report</Label>
                  <p className="text-sm text-neutral-500">Receive a weekly summary of your water usage</p>
                </div>
                <Switch 
                  id="weekly-report" 
                  checked={notifications.weeklyReport}
                  onCheckedChange={() => handleNotificationToggle('weeklyReport')}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="alerts">Critical Alerts</Label>
                  <p className="text-sm text-neutral-500">Get notified about critical water usage issues</p>
                </div>
                <Switch 
                  id="alerts" 
                  checked={notifications.alerts}
                  onCheckedChange={() => handleNotificationToggle('alerts')}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="dashboard" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dashboard Preferences</CardTitle>
              <CardDescription>Customize your dashboard layout and widgets</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="water-usage-chart">Water Usage Chart</Label>
                  <p className="text-sm text-neutral-500">Show water usage trends over time</p>
                </div>
                <Switch 
                  id="water-usage-chart" 
                  checked={dashboardPreferences.showWaterUsageChart}
                  onCheckedChange={() => handleDashboardToggle('showWaterUsageChart')}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="recommendations">Recommendations</Label>
                  <p className="text-sm text-neutral-500">Show water-saving recommendations</p>
                </div>
                <Switch 
                  id="recommendations" 
                  checked={dashboardPreferences.showRecommendations}
                  onCheckedChange={() => handleDashboardToggle('showRecommendations')}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="regional-map">Regional Map</Label>
                  <p className="text-sm text-neutral-500">Show water usage on regional map</p>
                </div>
                <Switch 
                  id="regional-map" 
                  checked={dashboardPreferences.showRegionalMap}
                  onCheckedChange={() => handleDashboardToggle('showRegionalMap')}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="weather-data">Weather Data</Label>
                  <p className="text-sm text-neutral-500">Show current weather conditions</p>
                </div>
                <Switch 
                  id="weather-data" 
                  checked={dashboardPreferences.showWeatherData}
                  onCheckedChange={() => handleDashboardToggle('showWeatherData')}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Default View</CardTitle>
              <CardDescription>Set your preferred initial dashboard view</CardDescription>
            </CardHeader>
            <CardContent>
              <Select defaultValue="overview">
                <SelectTrigger className="w-full md:w-[300px]">
                  <SelectValue placeholder="Select view" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="overview">Overview</SelectItem>
                  <SelectItem value="detailed">Detailed Analysis</SelectItem>
                  <SelectItem value="recommendations">Recommendations</SelectItem>
                  <SelectItem value="regional">Regional Comparison</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="data" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Unit Preferences</CardTitle>
              <CardDescription>Configure your preferred measurement units</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Measurement System</Label>
                <RadioGroup
                  value={units}
                  onValueChange={setUnits}
                  className="flex space-x-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="metric" id="metric" defaultChecked disabled />
                    <Label htmlFor="metric">Metric (m³/ha, t/ha)</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label>Date Format</Label>
                <Select defaultValue="YYYY-MM-DD">
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="Select format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                    <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                    <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label htmlFor="refresh-interval">Data Refresh Interval (minutes)</Label>
                  <span className="font-semibold">{dataRefreshInterval} min</span>
                </div>
                <Slider 
                  id="refresh-interval"
                  min={1} 
                  max={60} 
                  step={1} 
                  defaultValue={[dataRefreshInterval]} 
                  onValueChange={(value) => setDataRefreshInterval(value[0])}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Indian Agriculture Data Sources</CardTitle>
              <CardDescription>Connect to official Indian agriculture and weather data sources</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div>
                    <h4 className="font-semibold">Indian Meteorological Department (IMD)</h4>
                    <p className="text-sm text-neutral-500">Weather and rainfall data for agricultural planning</p>
                  </div>
                  <Switch defaultChecked id="imd-data" />
                </div>
                
                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div>
                    <h4 className="font-semibold">Soil Health Card Database</h4>
                    <p className="text-sm text-neutral-500">Connect to soil data from the National Soil Health Program</p>
                  </div>
                  <Switch id="soil-health-data" />
                </div>
                
                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div>
                    <h4 className="font-semibold">ICAR Crop Database</h4>
                    <p className="text-sm text-neutral-500">Indian Council of Agricultural Research crop reference data</p>
                  </div>
                  <Switch defaultChecked id="icar-data" />
                </div>
                
                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div>
                    <h4 className="font-semibold">Central Water Commission</h4>
                    <p className="text-sm text-neutral-500">Reservoir levels and river basin water availability</p>
                  </div>
                  <Switch id="cwc-data" />
                </div>
                
                <div className="flex items-center justify-between border p-3 rounded-md">
                  <div>
                    <h4 className="font-semibold">ISRO Satellite Data</h4>
                    <p className="text-sm text-neutral-500">Remote sensing data for crop monitoring and soil moisture</p>
                  </div>
                  <Switch defaultChecked id="isro-data" />
                </div>
              </div>
            </CardContent>
          </Card>
        
          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
              <CardDescription>Manage your data and exports</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-md p-4">
                <div className="flex items-start">
                  <i className="ri-information-line text-amber-500 mt-0.5 mr-2 text-lg"></i>
                  <div>
                    <h4 className="font-semibold text-amber-800">Data Export</h4>
                    <p className="text-sm text-amber-700">
                      You can export your water usage data for analysis in external tools.
                      Select your preferred format and date range below.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Format</Label>
                  <Select defaultValue="csv">
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="xlsx">Excel (XLSX)</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Date Range</Label>
                  <Select defaultValue="last30">
                    <SelectTrigger>
                      <SelectValue placeholder="Select range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="last30">Last 30 days</SelectItem>
                      <SelectItem value="last90">Last 90 days</SelectItem>
                      <SelectItem value="year">This year</SelectItem>
                      <SelectItem value="all">All time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button variant="outline" className="w-full">
                    <i className="ri-download-line mr-2"></i> Export Data
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="font-medium mb-2">Clear Data</h4>
                <div className="flex space-x-2">
                  <Button variant="outline" className="text-red-600 hover:bg-red-50 hover:text-red-700">
                    Clear Cache
                  </Button>
                  <Button variant="outline" className="text-red-600 hover:bg-red-50 hover:text-red-700">
                    Reset All Data
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
