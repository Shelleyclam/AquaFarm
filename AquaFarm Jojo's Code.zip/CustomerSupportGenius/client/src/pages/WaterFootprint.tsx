
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';

const WaterFootprint = () => {
  const { data: waterFootprintData } = useQuery<any[]>({
    queryKey: ['/api/water-footprints'],
    select: (data) => data?.map(item => ({
      date: new Date(item.date).toLocaleDateString(),
      waterUsage: item.waterUsage,
      efficiency: item.waterEfficiencyScore
    })) || []
  });

  const { data: crops } = useQuery<any[]>({
    queryKey: ['/api/crops'],
  });

  // Transform data for visualization
  const cropWaterData = crops?.map(crop => ({
    name: crop.name,
    waterRequirement: crop.waterRequirement,
    efficiency: crop.efficiency || 0,
  })) || [];

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center space-x-2 mb-2">
  <i className="ri-water-flash-line text-2xl text-blue-600"></i>
  <h2 className="text-2xl font-semibold text-neutral-900">Water Footprint Analysis</h2>
</div>
        <p className="text-neutral-500">
          Analyze water consumption patterns and efficiency across different crops and regions
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="crops">Crop Analysis</TabsTrigger>
          <TabsTrigger value="history">Historical Data</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Water Usage by Component</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={cropWaterData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="waterRequirement" name="Water Requirement (mm)" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Water Efficiency Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: 'Green Water', value: '60%', color: 'bg-green-100 text-green-800' },
                      { label: 'Blue Water', value: '30%', color: 'bg-blue-100 text-blue-800' },
                      { label: 'Grey Water', value: '10%', color: 'bg-neutral-100 text-neutral-800' },
                      { label: 'Overall Efficiency', value: '75%', color: 'bg-amber-100 text-amber-800' },
                    ].map((metric) => (
                      <div key={metric.label} className="p-4 rounded-lg border">
                        <p className="text-sm text-neutral-600">{metric.label}</p>
                        <Badge className={metric.color}>{metric.value}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="crops" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Crop Water Requirements</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Crop</TableHead>
                    <TableHead>Water Requirement (mm)</TableHead>
                    <TableHead>Efficiency Score</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {crops?.map((crop) => (
                    <TableRow key={crop.id}>
                      <TableCell className="font-medium">{crop.name}</TableCell>
                      <TableCell>{crop.waterRequirement}</TableCell>
                      <TableCell>{crop.efficiency || '-'}</TableCell>
                      <TableCell>
                        <Badge className={
                          crop.waterRequirement < 600 ? 'bg-green-100 text-green-800' :
                          crop.waterRequirement < 1000 ? 'bg-amber-100 text-amber-800' :
                          'bg-red-100 text-red-800'
                        }>
                          {crop.waterRequirement < 600 ? 'Efficient' :
                           crop.waterRequirement < 1000 ? 'Moderate' : 'High Usage'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Historical Water Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={waterFootprintData || []} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" angle={-45} textAnchor="end" height={60} />
                    <YAxis label={{ value: 'Water Usage (m³)', angle: -90, position: 'insideLeft' }} />
                    <Tooltip formatter={(value) => [`${value} m³`, 'Water Usage']} />
                    <Legend />
                    <Bar dataKey="waterUsage" name="Water Usage (m³)" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default WaterFootprint;
