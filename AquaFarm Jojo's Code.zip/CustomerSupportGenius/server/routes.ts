import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCropSchema, 
  insertRegionSchema, 
  insertIrrigationMethodSchema, 
  insertWaterFootprintSchema, 
  insertRecommendationSchema, 
  insertMonthlyWaterUsageSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all crops
  app.get("/api/crops", async (req: Request, res: Response) => {
    try {
      const crops = await storage.listCrops();
      res.json(crops);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch crops" });
    }
  });
  
  // Get all regions
  app.get("/api/regions", async (req: Request, res: Response) => {
    try {
      const regions = await storage.listRegions();
      res.json(regions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch regions" });
    }
  });
  
  // Get all irrigation methods
  app.get("/api/irrigation-methods", async (req: Request, res: Response) => {
    try {
      const methods = await storage.listIrrigationMethods();
      res.json(methods);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch irrigation methods" });
    }
  });
  
  // Get all recommendations
  app.get("/api/recommendations", async (req: Request, res: Response) => {
    try {
      const recommendations = await storage.listRecommendations();
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });
  
  // Get monthly water usage for the current and previous year
  app.get("/api/monthly-water-usage", async (req: Request, res: Response) => {
    try {
      const userId = 1; // For demonstration, we'll use the demo user
      const currentYear = new Date().getFullYear();
      const previousYear = currentYear - 1;
      
      const currentYearData = await storage.listMonthlyWaterUsage(userId, currentYear);
      const previousYearData = await storage.listMonthlyWaterUsage(userId, previousYear);
      
      res.json({
        currentYear: {
          year: currentYear,
          data: currentYearData.sort((a, b) => a.month - b.month)
        },
        previousYear: {
          year: previousYear,
          data: previousYearData.sort((a, b) => a.month - b.month)
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch monthly water usage data" });
    }
  });
  
  // Calculate water footprint
  app.post("/api/calculate-water-footprint", async (req: Request, res: Response) => {
    try {
      const calculationSchema = z.object({
        cropId: z.number().or(z.string().transform(v => parseInt(v, 10))),
        regionId: z.number().or(z.string().transform(v => parseInt(v, 10))),
        irrigationMethodId: z.number().or(z.string().transform(v => parseInt(v, 10))),
        area: z.number().or(z.string().transform(v => parseFloat(v))),
        growingSeason: z.string()
      });
      
      const validatedData = calculationSchema.parse(req.body);
      
      // Get related data
      const crop = await storage.getCrop(validatedData.cropId);
      const region = await storage.getRegion(validatedData.regionId);
      const irrigationMethod = await storage.getIrrigationMethod(validatedData.irrigationMethodId);
      
      if (!crop || !region || !irrigationMethod) {
        return res.status(400).json({ message: "Invalid input data" });
      }
      
      // Calculate water usage based on crop requirements and area
      // Apply irrigation efficiency to the calculation
      const baseWaterUsage = crop.waterRequirement * validatedData.area;
      const waterUsage = baseWaterUsage * (1 - irrigationMethod.efficiency);
      
      // Calculate efficiency score (0-100)
      // Higher efficiency means higher score
      const efficiencyScore = Math.round(irrigationMethod.efficiency * 100);
      
      // Calculate potential savings
      // This is based on the potential water savings of more efficient methods
      const potentialSavings = baseWaterUsage * irrigationMethod.waterSavings;
      
      // Create the water footprint record
      const waterFootprint = await storage.createWaterFootprint({
        userId: 1, // Using demo user
        cropId: validatedData.cropId,
        regionId: validatedData.regionId,
        irrigationMethodId: validatedData.irrigationMethodId,
        area: validatedData.area,
        waterUsage,
        waterEfficiencyScore: efficiencyScore,
        potentialSavings,
        growingSeason: validatedData.growingSeason
      });
      
      // Generate recommendations based on the footprint
      const allRecommendations = await storage.listRecommendations();
      const recommendations = allRecommendations.slice(0, 3); // Get first 3 recommendations
      
      // Return combined results
      res.json({
        waterFootprint,
        recommendations,
        crop,
        region,
        irrigationMethod
      });
    } catch (error) {
      console.error("Error calculating water footprint:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to calculate water footprint" });
    }
  });
  
  // Get dashboard stats
  app.get("/api/dashboard-stats", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Demo user
      
      // Get the last 12 months of water usage
      const currentYear = new Date().getFullYear();
      const previousYear = currentYear - 1;
      
      const currentYearData = await storage.listMonthlyWaterUsage(userId, currentYear);
      const previousYearData = await storage.listMonthlyWaterUsage(userId, previousYear);
      
      // Calculate total water usage for current year
      const totalWaterUsage = currentYearData.reduce((sum, month) => sum + month.waterUsage, 0);
      
      // Calculate total water usage for previous year
      const previousYearTotal = previousYearData.reduce((sum, month) => sum + month.waterUsage, 0);
      
      // Calculate percentage change
      const percentageChange = previousYearTotal > 0 
        ? ((totalWaterUsage - previousYearTotal) / previousYearTotal) * 100
        : 0;
      
      // Get irrigation methods for efficiency score calculation
      const irrigationMethods = await storage.listIrrigationMethods();
      const averageEfficiency = irrigationMethods.reduce((sum, method) => sum + method.efficiency, 0) / irrigationMethods.length;
      
      // Calculate efficiency score
      const efficiencyScore = Math.round(averageEfficiency * 100);
      
      // Calculate active croplands (for demo, use a fixed value)
      const activeCroplands = 142;
      
      // Calculate savings potential
      const savingsPotential = Math.round(totalWaterUsage * 0.155); // 15.5% of total
      
      res.json({
        totalWaterUsage: {
          value: Math.round(totalWaterUsage),
          unit: "m³",
          change: percentageChange.toFixed(1),
          changeDirection: percentageChange < 0 ? "down" : "up"
        },
        efficiencyScore: {
          value: efficiencyScore,
          unit: "/100",
          change: "3.1",
          changeDirection: "up"
        },
        activeCroplands: {
          value: activeCroplands,
          unit: "hectares",
          change: "5.7",
          changeDirection: "up"
        },
        savingsPotential: {
          value: savingsPotential,
          unit: "m³",
          percentage: "15.5"
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
