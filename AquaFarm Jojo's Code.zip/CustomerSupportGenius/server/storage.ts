import { 
  users, type User, type InsertUser,
  crops, type Crop, type InsertCrop,
  regions, type Region, type InsertRegion,
  irrigationMethods, type IrrigationMethod, type InsertIrrigationMethod,
  waterFootprints, type WaterFootprint, type InsertWaterFootprint,
  recommendations, type Recommendation, type InsertRecommendation,
  monthlyWaterUsage, type MonthlyWaterUsage, type InsertMonthlyWaterUsage
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Crop operations
  getCrop(id: number): Promise<Crop | undefined>;
  getCropByName(name: string): Promise<Crop | undefined>;
  listCrops(): Promise<Crop[]>;
  createCrop(crop: InsertCrop): Promise<Crop>;
  
  // Region operations
  getRegion(id: number): Promise<Region | undefined>;
  getRegionByName(name: string): Promise<Region | undefined>;
  listRegions(): Promise<Region[]>;
  createRegion(region: InsertRegion): Promise<Region>;
  
  // Irrigation Method operations
  getIrrigationMethod(id: number): Promise<IrrigationMethod | undefined>;
  getIrrigationMethodByName(name: string): Promise<IrrigationMethod | undefined>;
  listIrrigationMethods(): Promise<IrrigationMethod[]>;
  createIrrigationMethod(method: InsertIrrigationMethod): Promise<IrrigationMethod>;
  
  // Water Footprint operations
  getWaterFootprint(id: number): Promise<WaterFootprint | undefined>;
  listWaterFootprints(userId?: number): Promise<WaterFootprint[]>;
  createWaterFootprint(footprint: InsertWaterFootprint): Promise<WaterFootprint>;
  
  // Recommendation operations
  getRecommendation(id: number): Promise<Recommendation | undefined>;
  listRecommendations(): Promise<Recommendation[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  
  // Monthly Water Usage operations
  getMonthlyWaterUsage(id: number): Promise<MonthlyWaterUsage | undefined>;
  listMonthlyWaterUsage(userId: number, year?: number): Promise<MonthlyWaterUsage[]>;
  createMonthlyWaterUsage(usage: InsertMonthlyWaterUsage): Promise<MonthlyWaterUsage>;
}

export class DatabaseStorage implements IStorage {
  // User implementations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Crop implementations
  async getCrop(id: number): Promise<Crop | undefined> {
    const [crop] = await db.select().from(crops).where(eq(crops.id, id));
    return crop || undefined;
  }
  
  async getCropByName(name: string): Promise<Crop | undefined> {
    const [crop] = await db.select().from(crops).where(eq(crops.name, name));
    return crop || undefined;
  }
  
  async listCrops(): Promise<Crop[]> {
    return await db.select().from(crops);
  }
  
  async createCrop(insertCrop: InsertCrop): Promise<Crop> {
    const [crop] = await db
      .insert(crops)
      .values(insertCrop)
      .returning();
    return crop;
  }
  
  // Region implementations
  async getRegion(id: number): Promise<Region | undefined> {
    const [region] = await db.select().from(regions).where(eq(regions.id, id));
    return region || undefined;
  }
  
  async getRegionByName(name: string): Promise<Region | undefined> {
    const [region] = await db.select().from(regions).where(eq(regions.name, name));
    return region || undefined;
  }
  
  async listRegions(): Promise<Region[]> {
    return await db.select().from(regions);
  }
  
  async createRegion(insertRegion: InsertRegion): Promise<Region> {
    const [region] = await db
      .insert(regions)
      .values(insertRegion)
      .returning();
    return region;
  }
  
  // Irrigation Method implementations
  async getIrrigationMethod(id: number): Promise<IrrigationMethod | undefined> {
    const [method] = await db.select().from(irrigationMethods).where(eq(irrigationMethods.id, id));
    return method || undefined;
  }
  
  async getIrrigationMethodByName(name: string): Promise<IrrigationMethod | undefined> {
    const [method] = await db.select().from(irrigationMethods).where(eq(irrigationMethods.name, name));
    return method || undefined;
  }
  
  async listIrrigationMethods(): Promise<IrrigationMethod[]> {
    return await db.select().from(irrigationMethods);
  }
  
  async createIrrigationMethod(insertMethod: InsertIrrigationMethod): Promise<IrrigationMethod> {
    const [method] = await db
      .insert(irrigationMethods)
      .values(insertMethod)
      .returning();
    return method;
  }
  
  // Water Footprint implementations
  async getWaterFootprint(id: number): Promise<WaterFootprint | undefined> {
    const [footprint] = await db.select().from(waterFootprints).where(eq(waterFootprints.id, id));
    return footprint || undefined;
  }
  
  async listWaterFootprints(userId?: number): Promise<WaterFootprint[]> {
    if (userId) {
      return await db.select().from(waterFootprints).where(eq(waterFootprints.userId, userId));
    }
    return await db.select().from(waterFootprints);
  }
  
  async createWaterFootprint(insertFootprint: InsertWaterFootprint): Promise<WaterFootprint> {
    const [footprint] = await db
      .insert(waterFootprints)
      .values({
        ...insertFootprint,
        date: new Date()
      })
      .returning();
    return footprint;
  }
  
  // Recommendation implementations
  async getRecommendation(id: number): Promise<Recommendation | undefined> {
    const [recommendation] = await db.select().from(recommendations).where(eq(recommendations.id, id));
    return recommendation || undefined;
  }
  
  async listRecommendations(): Promise<Recommendation[]> {
    return await db.select().from(recommendations);
  }
  
  async createRecommendation(insertRecommendation: InsertRecommendation): Promise<Recommendation> {
    const [recommendation] = await db
      .insert(recommendations)
      .values(insertRecommendation)
      .returning();
    return recommendation;
  }
  
  // Monthly Water Usage implementations
  async getMonthlyWaterUsage(id: number): Promise<MonthlyWaterUsage | undefined> {
    const [usage] = await db.select().from(monthlyWaterUsage).where(eq(monthlyWaterUsage.id, id));
    return usage || undefined;
  }
  
  async listMonthlyWaterUsage(userId: number, year?: number): Promise<MonthlyWaterUsage[]> {
    if (year) {
      return await db.select().from(monthlyWaterUsage).where(
        and(
          eq(monthlyWaterUsage.userId, userId),
          eq(monthlyWaterUsage.year, year)
        )
      );
    }
    return await db.select().from(monthlyWaterUsage).where(eq(monthlyWaterUsage.userId, userId));
  }
  
  async createMonthlyWaterUsage(insertUsage: InsertMonthlyWaterUsage): Promise<MonthlyWaterUsage> {
    const [usage] = await db
      .insert(monthlyWaterUsage)
      .values(insertUsage)
      .returning();
    return usage;
  }
}

// Initialize the database with sample data if needed
async function initDb() {
  try {
    // Check if we have any crops, if not, add sample data
    const existingCrops = await db.select().from(crops);
    
    if (existingCrops.length === 0) {
      console.log("Initializing database with sample data...");
      
      // Add sample crops (India specific)
      const sampleCrops: InsertCrop[] = [
        { name: "Rice", waterRequirement: 1200, growingSeason: "Kharif", description: "Primary staple crop in India" },
        { name: "Wheat", waterRequirement: 450, growingSeason: "Rabi", description: "Major winter crop in Northern India" },
        { name: "Sugarcane", waterRequirement: 1500, growingSeason: "Year-Round", description: "Major cash crop in Western and Southern India" },
        { name: "Cotton", waterRequirement: 700, growingSeason: "Kharif", description: "Important fiber crop in Western and Central India" },
        { name: "Pulses", waterRequirement: 350, growingSeason: "Rabi/Kharif", description: "Various lentils and beans grown across India" },
        { name: "Maize", waterRequirement: 500, growingSeason: "Kharif", description: "Grown primarily in Northern and Southern regions" },
        { name: "Groundnut", waterRequirement: 600, growingSeason: "Kharif", description: "Important oilseed crop in Southern and Western India" },
        { name: "Bajra", waterRequirement: 350, growingSeason: "Kharif", description: "Drought-resistant millet grown in arid regions" },
        { name: "Jowar", waterRequirement: 400, growingSeason: "Kharif", description: "Important millet crop for drier regions" },
        { name: "Vegetables", waterRequirement: 400, growingSeason: "Year-Round", description: "Various vegetable crops across India" },
      ];
      
      for (const crop of sampleCrops) {
        await db.insert(crops).values(crop);
      }
      
      // Add sample regions (India specific)
      const sampleRegions: InsertRegion[] = [
        { name: "Indo-Gangetic Plains", averageRainfall: 800, climateZone: "Subtropical", coordinates: { lat: 25.3176, lng: 82.9739 } },
        { name: "Deccan Plateau", averageRainfall: 600, climateZone: "Semi-Arid", coordinates: { lat: 17.3850, lng: 78.4867 } },
        { name: "Western Coastal Plains", averageRainfall: 2500, climateZone: "Tropical", coordinates: { lat: 19.0760, lng: 72.8777 } },
        { name: "Eastern Coastal Plains", averageRainfall: 1200, climateZone: "Tropical", coordinates: { lat: 13.0827, lng: 80.2707 } },
        { name: "Himalayan Region", averageRainfall: 1600, climateZone: "Alpine", coordinates: { lat: 30.7333, lng: 79.0667 } },
        { name: "Central Highlands", averageRainfall: 500, climateZone: "Semi-Arid", coordinates: { lat: 22.7196, lng: 75.8577 } },
        { name: "Thar Desert", averageRainfall: 150, climateZone: "Arid", coordinates: { lat: 27.0238, lng: 74.2179 } },
        { name: "North-Eastern Region", averageRainfall: 2000, climateZone: "Subtropical", coordinates: { lat: 25.5788, lng: 91.8933 } },
      ];
      
      for (const region of sampleRegions) {
        await db.insert(regions).values(region);
      }
      
      // Add sample irrigation methods (India specific)
      const sampleIrrigationMethods: InsertIrrigationMethod[] = [
        { name: "Drip Irrigation", efficiency: 0.9, waterSavings: 0.4, description: "Water delivered directly to plant roots, popular in Maharashtra and Gujarat" },
        { name: "Surface Irrigation", efficiency: 0.5, waterSavings: 0, description: "Traditional method used across India, especially in paddy fields" },
        { name: "Check Basin Method", efficiency: 0.6, waterSavings: 0.1, description: "Common for irrigating crops like wheat and pulses in Northern India" },
        { name: "Surge Irrigation", efficiency: 0.65, waterSavings: 0.15, description: "Improved flood irrigation with controlled water surges" },
        { name: "Sprinkler System", efficiency: 0.75, waterSavings: 0.25, description: "Overhead watering with sprinklers, suitable for undulating terrain" },
        { name: "Sub-surface Irrigation", efficiency: 0.85, waterSavings: 0.35, description: "Underground water delivery, gaining popularity in water-scarce regions" },
        { name: "Micro Sprinkler", efficiency: 0.8, waterSavings: 0.3, description: "Small-scale sprinklers ideal for horticultural crops" },
        { name: "Pitcher Irrigation", efficiency: 0.8, waterSavings: 0.3, description: "Traditional method using buried clay pots for water conservation" },
        { name: "Lift Irrigation", efficiency: 0.55, waterSavings: 0.05, description: "Water lifted from wells or canals, common in canal command areas" },
        { name: "Underground Pipeline System", efficiency: 0.75, waterSavings: 0.25, description: "Reduces evaporation losses, used in central and southern regions" }
      ];
      
      for (const method of sampleIrrigationMethods) {
        await db.insert(irrigationMethods).values(method);
      }
      
      // Add sample recommendations (India specific)
      const sampleRecommendations: InsertRecommendation[] = [
        { 
          title: "Switch to drip irrigation for sugarcane fields",
          description: "Reduces water usage by up to 40% compared to flood irrigation commonly used in India",
          impact: "High",
          savingsPercentage: 0.4,
          icon: "ri-drop-line"
        },
        { 
          title: "Implement System of Rice Intensification (SRI)",
          description: "SRI techniques can save 30-40% water while increasing rice yields by 20-30%",
          impact: "High",
          savingsPercentage: 0.35,
          icon: "ri-plant-line"
        },
        { 
          title: "Use water metering and scheduling",
          description: "Precise water application according to crop stages and monsoon forecasts",
          impact: "High",
          savingsPercentage: 0.25,
          icon: "ri-dashboard-line"
        },
        { 
          title: "Install rainwater harvesting systems",
          description: "Traditional Indian rainwater collection systems can reduce groundwater dependence",
          impact: "High",
          savingsPercentage: 0.3,
          icon: "ri-cloud-line"
        },
        { 
          title: "Implement laser land leveling",
          description: "Precision land leveling reduces water runoff by up to 25% in paddy fields",
          impact: "Medium",
          savingsPercentage: 0.25,
          icon: "ri-ruler-line"
        },
        { 
          title: "Adopt mulching techniques",
          description: "Organic mulching is ideal for vegetable crops in both Kharif and Rabi seasons",
          impact: "Medium",
          savingsPercentage: 0.15,
          icon: "ri-landscape-line"
        },
        { 
          title: "Switch to drought-resistant varieties",
          description: "Indian Agricultural Research Institute (IARI) developed varieties require less water",
          impact: "Medium",
          savingsPercentage: 0.2,
          icon: "ri-seedling-line"
        },
        { 
          title: "Implement canal lining techniques",
          description: "Reduces water seepage from irrigation canals by up to 30% in large farms",
          impact: "Medium",
          savingsPercentage: 0.3,
          icon: "ri-road-map-line"
        },
        { 
          title: "Use solar-powered micro-irrigation",
          description: "Combined approach for sustainable water and energy use in farms",
          impact: "High",
          savingsPercentage: 0.35,
          icon: "ri-sun-line"
        },
        { 
          title: "Adopt crop rotation with pulses",
          description: "Reduces water needs and improves soil nitrogen levels naturally",
          impact: "Medium",
          savingsPercentage: 0.15,
          icon: "ri-repeat-line"
        }
      ];
      
      for (const rec of sampleRecommendations) {
        await db.insert(recommendations).values(rec);
      }
      
      // Add demo user (Indian name)
      const [user] = await db.insert(users).values({
        username: "demo",
        password: "password",
        fullName: "Raj Patel",
        role: "Kisan (Farmer)"
      }).returning();
      
      // Add sample monthly water usage data
      const currentYear = new Date().getFullYear();
      const previousYear = currentYear - 1;
      
      const currentYearData = [2100, 1950, 2250, 2400, 2650, 2800, 2950, 2700, 2400, 2200, 2000, 1950];
      const previousYearData = [2300, 2150, 2450, 2650, 2850, 3100, 3200, 2950, 2650, 2450, 2250, 2100];
      
      for (let month = 1; month <= 12; month++) {
        await db.insert(monthlyWaterUsage).values({
          userId: user.id,
          month,
          year: currentYear,
          waterUsage: currentYearData[month - 1]
        });
        
        await db.insert(monthlyWaterUsage).values({
          userId: user.id,
          month,
          year: previousYear,
          waterUsage: previousYearData[month - 1]
        });
      }
      
      console.log("Database initialization complete");
    }
  } catch (error) {
    console.error("Error initializing database:", error);
  }
}

// Initialize and export the storage instance
const storage = new DatabaseStorage();

// Initialize database with sample data
initDb().catch(console.error);

export { storage };