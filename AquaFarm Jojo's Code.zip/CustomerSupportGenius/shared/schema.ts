import { pgTable, text, serial, integer, boolean, json, real, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").default("user").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
});

// Crops table
export const crops = pgTable("crops", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  waterRequirement: real("water_requirement").notNull(), // cubic meters per hectare
  growingSeason: text("growing_season").notNull(),
  description: text("description"),
});

export const insertCropSchema = createInsertSchema(crops).pick({
  name: true,
  waterRequirement: true,
  growingSeason: true,
  description: true,
});

// Regions table
export const regions = pgTable("regions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  averageRainfall: real("average_rainfall").notNull(), // millimeters per year
  climateZone: text("climate_zone").notNull(),
  coordinates: json("coordinates").notNull(), // GeoJSON
});

export const insertRegionSchema = createInsertSchema(regions).pick({
  name: true,
  averageRainfall: true,
  climateZone: true,
  coordinates: true,
});

// Irrigation methods table
export const irrigationMethods = pgTable("irrigation_methods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  efficiency: real("efficiency").notNull(), // percentage 0-1
  waterSavings: real("water_savings").notNull(), // percentage 0-1
  description: text("description"),
});

export const insertIrrigationMethodSchema = createInsertSchema(irrigationMethods).pick({
  name: true,
  efficiency: true,
  waterSavings: true,
  description: true,
});

// Water footprint calculations table
export const waterFootprints = pgTable("water_footprints", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  cropId: integer("crop_id").notNull().references(() => crops.id),
  regionId: integer("region_id").notNull().references(() => regions.id),
  irrigationMethodId: integer("irrigation_method_id").notNull().references(() => irrigationMethods.id),
  area: real("area").notNull(), // hectares
  waterUsage: real("water_usage").notNull(), // cubic meters
  waterEfficiencyScore: real("water_efficiency_score").notNull(), // 0-100
  potentialSavings: real("potential_savings").notNull(), // cubic meters
  date: timestamp("date").notNull().defaultNow(),
  growingSeason: text("growing_season").notNull(),
});

export const insertWaterFootprintSchema = createInsertSchema(waterFootprints).pick({
  userId: true,
  cropId: true,
  regionId: true,
  irrigationMethodId: true,
  area: true,
  waterUsage: true,
  waterEfficiencyScore: true,
  potentialSavings: true,
  growingSeason: true,
});

// Recommendations table
export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  impact: text("impact").notNull(), // High, Medium, Low
  savingsPercentage: real("savings_percentage").notNull(), // 0-1
  icon: text("icon").notNull(),
});

export const insertRecommendationSchema = createInsertSchema(recommendations).pick({
  title: true,
  description: true,
  impact: true,
  savingsPercentage: true,
  icon: true,
});

// Monthly water usage table for historical data
export const monthlyWaterUsage = pgTable("monthly_water_usage", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  month: integer("month").notNull(), // 1-12
  year: integer("year").notNull(),
  waterUsage: real("water_usage").notNull(), // cubic meters
});

export const insertMonthlyWaterUsageSchema = createInsertSchema(monthlyWaterUsage).pick({
  userId: true,
  month: true,
  year: true,
  waterUsage: true,
});

// Define export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Crop = typeof crops.$inferSelect;
export type InsertCrop = z.infer<typeof insertCropSchema>;

export type Region = typeof regions.$inferSelect;
export type InsertRegion = z.infer<typeof insertRegionSchema>;

export type IrrigationMethod = typeof irrigationMethods.$inferSelect;
export type InsertIrrigationMethod = z.infer<typeof insertIrrigationMethodSchema>;

export type WaterFootprint = typeof waterFootprints.$inferSelect;
export type InsertWaterFootprint = z.infer<typeof insertWaterFootprintSchema>;

export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;

export type MonthlyWaterUsage = typeof monthlyWaterUsage.$inferSelect;
export type InsertMonthlyWaterUsage = z.infer<typeof insertMonthlyWaterUsageSchema>;
